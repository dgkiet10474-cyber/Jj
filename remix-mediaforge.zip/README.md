# MediaForge - Bộ Công Cụ Xử Lý Video & Âm Thanh Offline (Android Native)

MediaForge là ứng dụng Android Native phát triển bằng **Kotlin**, **Jetpack Compose**, và **Material 3**. Ứng dụng cung cấp trọn bộ công cụ xử lý tệp tin đa phương tiện hoàn toàn **OFFLINE** ngay trên thiết bị, sử dụng thư viện **FFmpegKit maintained v7.1.6**.

---

## 🌟 Tính Năng Nổi Bật

1. **Chuyển đổi (Convert)**:
   - Hỗ trợ đầy đủ **10 định dạng âm thanh**: `MP3`, `WAV`, `M4A`, `AAC`, `FLAC`, `OGG`, `OPUS`, `WMA`, `AIFF`, `AMR`.
   - Tùy chỉnh Bitrate (64k - 320k), Tần số lấy mẫu (Sample rate), Kênh âm thanh (Mono/Stereo).
   - Tự động tách âm thanh từ video (`-vn`).
   - Tính năng phụ: Chuyển đổi định dạng video sang **MP4** tiêu chuẩn.

2. **Cắt (Trim)**:
   - Tích hợp trình phát nghe/xem trước bằng **Media3 ExoPlayer**.
   - Thiết lập điểm đầu/cuối bằng nhập liệu `hh:mm:ss.SSS` hoặc bấm **"Lấy vị trí hiện tại"** từ thanh phát.
   - Cắt video với 2 chế độ:
     - **Cắt nhanh** (`-c copy`): Xuất siêu tốc, không re-encode, giữ nguyên 100% chất lượng gốc.
     - **Cắt chính xác**: Khớp từng khung hình mili-giây với bộ mã hóa tối ưu.

3. **Nén (Compress)**:
   - **Nén âm thanh**: Chọn bitrate mục tiêu (32/64/96/128 kbps), tùy chọn xuất sang `.m4a` hoặc `.mp3`.
   - **Nén video**: 3 preset chuẩn hóa:
     - **Nhẹ**: 1080p, Video 4 Mbps, Audio 128 kbps.
     - **Vừa**: 720p, Video 2 Mbps, Audio 96 kbps (giảm ~50-70%).
     - **Mạnh**: 480p, Video 1 Mbps, Audio 64 kbps (giảm ~70-85%).
   - Tự động hiển thị dung lượng gốc, dung lượng ước tính và phần trăm tiết kiệm.

4. **Đổi tốc độ (Speed)**:
   - Thanh trượt từ **0.25x đến 4.0x** (bước nhảy 0.05) kèm nút chọn nhanh (0.5x, 1x, 1.5x, 2x).
   - Xử lý chuỗi bộ lọc `atempo` đa tầng khi vượt ngoài khoảng 0.5 - 2.0 (ví dụ 4.0x = `atempo=2.0,atempo=2.0`).
   - Tùy chọn: **"Giữ nguyên cao độ"** (giọng bình thường) hoặc **"Đổi cả cao độ"** (`asetrate` - hiệu ứng sóc chuột / giọng trầm ma quái).

5. **Tua ngược (Reverse)**:
   - Tua ngược hình ảnh (`-vf reverse`) và âm thanh (`-af areverse`).
   - Cảnh báo an toàn RAM và giới hạn độ dài file tránh lỗi tràn bộ nhớ (OOM).

6. **Tiến trình chạy nền & Quản lý file**:
   - Chạy ngầm an toàn qua **Foreground Service** (`dataSync`) kèm thanh tiến độ Notification.
   - Tự động lưu kết quả vào thư mục công khai của hệ thống: `Movies/MediaForge` (video) và `Music/MediaForge` (audio) qua MediaStore.
   - Hộp thoại lỗi hiển thị **20 dòng log cuối của FFmpeg** cùng nút **"Sao chép log"**.
   - Tự động dọn dẹp bộ nhớ đệm cache khi khởi động.

---

## 🛠️ Hướng Dẫn Build Bằng GitHub Actions

File workflow đã được cấu hình sẵn tại `.github/workflows/build.yml` với `gradle-version: 9.3.1` (phải khớp AGP mà project dùng; AGP 9.x cần Gradle >= 9.3.1).

### Các bước:
1. Đẩy mã nguồn lên kho lưu trữ GitHub của bạn (`git push origin main`).
2. Chuyển sang tab **Actions** trên GitHub.
3. Chọn workflow **Build Debug APK** và nhấn **Run workflow** (hoặc tự động kích hoạt khi có push/PR).
4. Sau khi tiến trình hoàn tất, tải file APK debug tại mục **Artifacts** (`MediaForge-debug-apk`).

---

## ⚠️ Các Lỗi Thường Gặp & Cách Khắc Phục

### 1. Lỗi Resolve Dependency `ffmpeg-kit`
- **Nguyên nhân**: `com.arthenica:ffmpeg-kit` gốc đã ngừng hoạt động và bị gỡ khỏi Maven Central.
- **Giải pháp**: Dự án sử dụng bản fork chính thức được duy trì:
  ```kotlin
  implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full:7.1.6")
  ```
  Nếu môi trường mạng của bạn chặn hoặc không tải được từ MavenCentral, kho lưu trữ phụ `maven("https://jitpack.io")` đã được cấu hình sẵn trong `settings.gradle.kts`.

### 2. Thiếu Bộ Mã Hóa (Encoder: `libmp3lame`, `libx264`)
- **Nguyên nhân**: Bản `ffmpeg-kit-full` tuân thủ giấy phép LGPL, do đó không kèm theo các codec mã nguồn đóng/GPL như `libx264` hoặc `libmp3lame`.
- **Giải pháp trong code**:
  - Khi xuất MP3, nếu thiếu `libmp3lame`, app sẽ tự động dùng bộ mã hóa `aac` hoặc khuyên người dùng chọn định dạng `.m4a` (chất lượng âm thanh tương đương/tốt hơn).
  - Video tự động ưu tiên bộ giải mã phần cứng thiết bị `h264_mediacodec`, nếu không có sẽ dùng `mpeg4`.
- **Nâng cấp lên bản GPL**: Nếu bạn muốn đầy đủ `libx264` và `libmp3lame`, đổi dependency trong `app/build.gradle.kts` thành:
  ```kotlin
  implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full-gpl:7.1.6")
  ```

### 3. Hết RAM Khi Tua Ngược (Out Of Memory với Reverse)
- **Nguyên nhân**: Bộ lọc `reverse` và `areverse` của FFmpeg hoạt động bằng cách nạp toàn bộ các khung hình không nén của video vào RAM trước khi ghi ngược lại. Video 1080p 30fps có thể tốn hơn 1-2 GB RAM chỉ trong 10-20 giây.
- **Giải pháp**:
  - MediaForge đã đặt cảnh báo và khuyến cáo chỉ tua ngược video **dưới 60 giây**.
  - Nếu video dài, hãy dùng tab **Cắt (Trim)** để cắt đoạn ngắn cần tua ngược trước khi thực hiện.

---

## 🚀 Baseline Profile & Tối Ưu Khởi Động

Dự án đã tích hợp module `:baselineprofile` để tăng tốc độ khởi động (Cold Startup) và giảm giật lag khung hình khi mở màn hình lần đầu:

- **Môi trường yêu cầu**: Module `:baselineprofile` **CHỈ chạy được trên thiết bị/máy ảo Android thật** (yêu cầu kết nối `adb` và đã cài đặt ứng dụng trên máy). Module này **KHÔNG chạy được** trong tiến trình `gradle assembleDebug` hoặc `assembleRelease` thông thường trên GitHub Actions (do môi trường runner GitHub Actions mặc định không có Android emulator/device).
- **Đảm bảo CI không bị gián đoạn**: Trong `app/build.gradle.kts`, cờ `automaticGenerationDuringBuild = false` đã được kích hoạt, đảm bảo lệnh `./gradlew assembleDebug` trên GitHub Actions chạy hoàn toàn bình thường và không bao giờ bị lỗi do thiếu thiết bị kết nối.
- **Quy tắc Baseline Profile có sẵn**: File quy tắc tối ưu đã được cấu hình và commit sẵn tại:
  ```
  app/src/main/baseline-prof.txt
  ```
- **Cách tự sinh (generate) lại Baseline Profile trên máy thật**:
  1. Kết nối điện thoại Android thật (bật USB Debugging) hoặc khởi chạy một Android Emulator (API 33+ hoặc 28+).
  2. Mở terminal tại thư mục gốc dự án và chạy:
     ```bash
     ./gradlew :app:generateReleaseBaselineProfile
     ```
  3. Quá trình kiểm thử Macrobenchmark sẽ tự động mở ứng dụng, thực hiện hành trình khởi động -> Trang chủ -> Chuyển đổi âm thanh và xuất ra file profile tối ưu mới nhất vào thư mục app.

