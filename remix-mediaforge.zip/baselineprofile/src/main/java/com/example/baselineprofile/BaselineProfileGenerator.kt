package com.example.baselineprofile

import androidx.benchmark.macro.junit4.BaselineProfileRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.uiautomator.By
import androidx.test.uiautomator.Until
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * BaselineProfileGenerator mô phỏng hành trình người dùng chính (CUJ):
 * 1. Khởi động ứng dụng (Cold start)
 * 2. Mở màn hình chức năng hay dùng nhất (Trang chủ -> Chuyển đổi âm thanh)
 * 3. Thao tác và quay lại Trang chủ
 *
 * Lưu ý: Module này yêu cầu thiết bị vật lý hoặc emulator thật có kết nối ADB.
 * Lệnh chạy: ./gradlew :app:generateReleaseBaselineProfile
 */
@RunWith(AndroidJUnit4::class)
class BaselineProfileGenerator {

    @get:Rule
    val baselineProfileRule = BaselineProfileRule()

    @Test
    fun generate() {
        baselineProfileRule.collect(
            packageName = "com.aistudio.applet.oslzlc"
        ) {
            // 1. Khởi động ứng dụng
            pressHome()
            startActivityAndWait()

            // 2. Chờ màn hình Trang chủ hiển thị
            device.wait(Until.hasObject(By.text("MediaForge Studio")), 5000)

            // 3. Vào màn hình chức năng hay dùng nhất: Chuyển đổi âm thanh
            val convertButton = device.findObject(By.text("Video sang\nÂm thanh"))
                ?: device.findObject(By.text("Chuyển đổi Nhạc"))
            convertButton?.click()

            // 4. Chờ giao diện chuyển đổi ổn định
            device.waitForIdle()

            // 5. Quay lại Trang chủ
            device.pressBack()
            device.waitForIdle()
        }
    }
}
