package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.FFmpegCommands
import com.example.util.FileUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("MediaForge", appName)
    }

    @Test
    fun `test formatFileSize`() {
        val formatted = FileUtils.formatFileSize(1048576)
        assertEquals("1.00 MB", formatted)
    }

    @Test
    fun `test parseDurationToMs`() {
        val ms = FileUtils.parseDurationToMs("00:01:30.500")
        assertEquals(90500L, ms)
    }

    @Test
    fun `test ffmpeg audio convert command`() {
        val args = FFmpegCommands.buildConvertAudioCommand(
            inputPath = "/path/to/input.mp4",
            outputPath = "/path/to/output.m4a",
            format = "m4a",
            bitrateKbps = 192
        )
        assertTrue(args.contains("-vn"))
        assertTrue(args.contains("aac"))
        assertTrue(args.contains("/path/to/output.m4a"))
    }

    @Test
    fun `test atempo chaining for 4x speed`() {
        val filter = FFmpegCommands.buildAtempoFilter(4.0f)
        assertTrue(filter.contains("atempo=2.0"))
    }
}
