package com.example

import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testStripMetadataArgs() {
    val mp3Args = com.example.engine.FFmpegCommands.stripMetadataArgs("mp3")
    assertTrue(mp3Args.contains("-map_metadata"))
    assertTrue(mp3Args.contains("-1"))
    assertTrue(mp3Args.contains("-id3v2_version"))
    assertTrue(mp3Args.contains("0"))

    val m4aArgs = com.example.engine.FFmpegCommands.stripMetadataArgs("m4a")
    assertTrue(m4aArgs.contains("-map_metadata"))
    assertTrue(m4aArgs.contains("-1"))
    assertFalse(m4aArgs.contains("-id3v2_version"))
  }
}
