package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.arthenica.ffmpegkit.FFprobeKit
import com.example.engine.FFmpegCommands
import com.example.engine.ProcessingManager
import com.example.ui.components.MediaPreviewPlayer
import com.example.ui.components.StudioActionButton
import com.example.ui.components.StudioFilePickerCard
import com.example.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReverseScreen(targetMediaType: String? = null) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedFileName by remember { mutableStateOf("") }
    var selectedFileSize by remember { mutableLongStateOf(0L) }
    var isVideoInput by remember { mutableStateOf(targetMediaType != "audio") }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            selectedFileName = FileUtils.getFileName(context, uri)
            selectedFileSize = FileUtils.getFileSize(context, uri)
            val extension = selectedFileName.substringAfterLast('.', "").lowercase()
            val videoExts = listOf("mp4", "mkv", "mov", "avi", "webm", "flv", "3gp", "wmv", "m4v")
            isVideoInput = if (targetMediaType == "audio") false else if (targetMediaType == "video") true else (videoExts.contains(extension) || uri.toString().contains("video"))
        }
    }

    val targetMimes = when (targetMediaType) {
        "video" -> arrayOf("video/*")
        "audio" -> arrayOf("audio/*")
        else -> arrayOf("audio/*", "video/*")
    }

    var showWarningDialog by remember { mutableStateOf(false) }

    if (showWarningDialog) {
        AlertDialog(
            onDismissRequest = { showWarningDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            },
            title = {
                Text(
                    text = "Lưu ý quan trọng về bộ nhớ (RAM)",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "Bộ lọc tua ngược (reverse/areverse) phải nạp toàn bộ khung hình và âm thanh vào bộ nhớ RAM của thiết bị trước khi đảo chiều.\n\n" +
                            "Để tránh tràn RAM (OOM) làm crash app:\n" +
                            "• Video: Giới hạn tối đa 60 giây (nếu video dài, vui lòng dùng tính năng Cắt trước).\n" +
                            "• Âm thanh: Giới hạn tối đa 10 phút.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(onClick = { showWarningDialog = false }) {
                    Text("Đã hiểu")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Banner thông tin giới hạn RAM
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Lưu ý RAM",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Video: tối đa 60s • Âm thanh: tối đa 10 phút",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Tránh tràn RAM khi nạp đảo khung hình",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TextButton(
                    onClick = { showWarningDialog = true },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Chi tiết",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // File Selection Card
        StudioFilePickerCard(
            selectedUri = selectedUri,
            selectedFileName = selectedFileName,
            selectedFileSize = selectedFileSize,
            isVideoInput = isVideoInput,
            onPickClick = { filePicker.launch(targetMimes) },
            previewContent = {
                if (selectedUri != null) {
                    MediaPreviewPlayer(
                        uri = selectedUri!!,
                        isVideo = isVideoInput
                    )
                }
            }
        )

        if (selectedUri != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Chi tiết xử lý",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isVideoInput)
                            "Sẽ đảo ngược toàn bộ hình ảnh (-vf reverse) và âm thanh (-af areverse) từ cuối về đầu."
                        else
                            "Sẽ đảo ngược chuỗi âm thanh (-af areverse) từ cuối về đầu.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Action Button
            Button(
                onClick = {
                    val uri = selectedUri ?: return@Button
                    if (ProcessingManager.isRunning()) {
                        Toast.makeText(context, "Đang có tác vụ khác đang chạy!", Toast.LENGTH_SHORT).show()
                        return@Button
                    }

                    coroutineScope.launch {
                        val inputCache = withContext(Dispatchers.IO) {
                            FileUtils.copyUriToCache(context, uri, "rev_in")
                        }
                        if (inputCache == null) {
                            Toast.makeText(context, "Không thể đọc file từ bộ nhớ!", Toast.LENGTH_LONG).show()
                            return@launch
                        }

                        val baseName = selectedFileName.substringBeforeLast('.')
                        val ext = selectedFileName.substringAfterLast('.', if (isVideoInput) "mp4" else "m4a")

                        // Lấy bitrate và fps gốc trên IO thread để tính GOP và bitrate tối ưu cho output
                        val (originalBitrateBps, outputFps) = withContext(Dispatchers.IO) {
                            if (isVideoInput) {
                                var probedBitrate: Long? = null
                                var fpsVal = 30
                                try {
                                    val mediaInfo = FFprobeKit.getMediaInformation(inputCache.absolutePath)?.mediaInformation
                                    if (mediaInfo != null) {
                                        probedBitrate = mediaInfo.bitrate?.toLongOrNull()
                                        if (probedBitrate == null || probedBitrate <= 0) {
                                            val dur = mediaInfo.duration?.toDoubleOrNull() ?: 0.0
                                            if (dur > 0) {
                                                probedBitrate = ((inputCache.length() * 8) / dur).toLong()
                                            }
                                        }
                                        val videoStream = mediaInfo.streams?.firstOrNull { it.type == "video" }
                                        val rFrameRate = videoStream?.realFrameRate
                                        if (rFrameRate != null && rFrameRate.contains("/")) {
                                            val parts = rFrameRate.split("/")
                                            val num = parts[0].toDoubleOrNull()
                                            val den = parts[1].toDoubleOrNull()
                                            if (num != null && den != null && den > 0) {
                                                val parsed = (num / den).toInt()
                                                if (parsed in 15..120) fpsVal = parsed
                                            }
                                        } else if (rFrameRate != null) {
                                            rFrameRate.toDoubleOrNull()?.toInt()?.let {
                                                if (it in 15..120) fpsVal = it
                                            }
                                        }
                                    }
                                } catch (_: Throwable) {}
                                Pair(probedBitrate, fpsVal)
                            } else {
                                Pair(null, 30)
                            }
                        }

                        val outputCache = FileUtils.createTempOutputFile(context, "rev_out", ext)
                        val targetDisplayName = "${baseName}_reverse_${System.currentTimeMillis()}.$ext"

                        val args = FFmpegCommands.buildReverseCommand(
                            inputPath = inputCache.absolutePath,
                            outputPath = outputCache.absolutePath,
                            isVideo = isVideoInput,
                            originalBitrateBps = originalBitrateBps,
                            outputFps = outputFps
                        )

                        ProcessingManager.runTask(
                            context = context,
                            taskTitle = if (isVideoInput) "Tua ngược video" else "Tua ngược âm thanh",
                            inputCacheFile = inputCache,
                            outputCacheFile = outputCache,
                            isVideo = isVideoInput,
                            targetDisplayName = targetDisplayName,
                            argsArray = args
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.FastRewind, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isVideoInput) "Bắt đầu tua ngược video" else "Bắt đầu tua ngược âm thanh",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
