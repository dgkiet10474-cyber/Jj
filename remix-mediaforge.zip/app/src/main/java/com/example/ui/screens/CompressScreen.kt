package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.FFmpegCommands
import com.example.engine.ProcessingManager
import com.example.ui.components.MediaPreviewPlayer
import com.example.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompressScreen(targetMediaType: String? = null) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedFileName by remember { mutableStateOf("") }
    var selectedFileSize by remember { mutableLongStateOf(0L) }
    var isVideoInput by remember { mutableStateOf(targetMediaType != "audio") }

    // Audio compress options
    val audioBitrates = listOf(32, 64, 96, 128)
    var selectedAudioBitrate by remember { mutableIntStateOf(64) }
    var audioTargetFormat by remember { mutableStateOf("m4a") } // m4a or mp3

    // Video compress presets: 0 = Nhẹ (1080p, 4M), 1 = Vừa (720p, 2M), 2 = Mạnh (480p, 1M)
    var videoPresetIndex by remember { mutableIntStateOf(1) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            selectedFileName = FileUtils.getFileName(context, uri)
            selectedFileSize = FileUtils.getFileSize(context, uri)
            val extension = selectedFileName.substringAfterLast('.', "").lowercase()
            val videoExts = listOf("mp4", "mkv", "mov", "avi", "webm", "flv", "3gp", "wmv", "m4v")
            isVideoInput = if (targetMediaType == "audio") false else if (targetMediaType == "video") true else (videoExts.contains(extension) || uri.toString().contains("video"))
        }
    }

    val targetMimes = when (targetMediaType) {
        "video" -> arrayOf("video/*")
        "audio" -> arrayOf("audio/*")
        else -> arrayOf("audio/*", "video/*")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // File selection card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isVideoInput) Icons.Default.VideoFile else Icons.Default.Audiotrack,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (selectedUri != null) "File cần nén" else "Chưa chọn file",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = { filePicker.launch(targetMimes) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Chọn file")
                    }
                }

                if (selectedUri != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = selectedFileName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Dung lượng gốc: ${FileUtils.formatFileSize(selectedFileSize)} • ${if (isVideoInput) "Video" else "Âm thanh"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    MediaPreviewPlayer(
                        uri = selectedUri!!,
                        isVideo = isVideoInput
                    )
                }
            }
        }

        if (selectedUri != null) {
            if (isVideoInput) {
                // Video Compression Presets
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Mức độ nén video",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                            SegmentedButton(
                                selected = videoPresetIndex == 0,
                                onClick = { videoPresetIndex = 0 },
                                shape = SegmentedButtonDefaults.itemShape(index = 0, count = 3)
                            ) {
                                Text("Nhẹ")
                            }
                            SegmentedButton(
                                selected = videoPresetIndex == 1,
                                onClick = { videoPresetIndex = 1 },
                                shape = SegmentedButtonDefaults.itemShape(index = 1, count = 3)
                            ) {
                                Text("Vừa")
                            }
                            SegmentedButton(
                                selected = videoPresetIndex == 2,
                                onClick = { videoPresetIndex = 2 },
                                shape = SegmentedButtonDefaults.itemShape(index = 2, count = 3)
                            ) {
                                Text("Mạnh")
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        val presetDesc = when (videoPresetIndex) {
                            0 -> "Độ phân giải: 1080p (Scale -2:1080) • Bitrate: 4 Mbps • Audio: 128 kbps. Phù hợp giữ độ nét cao, giảm khoảng 20-40%."
                            1 -> "Độ phân giải: 720p (Scale -2:720) • Bitrate: 2 Mbps • Audio: 96 kbps. Khuyên dùng, cân bằng tốt độ nét và dung lượng, giảm ~50-70%."
                            else -> "Độ phân giải: 480p (Scale -2:480) • Bitrate: 1 Mbps • Audio: 64 kbps. Nén tối đa để gửi qua mạng/Zalo, giảm ~70-85%."
                        }

                        Text(
                            text = presetDesc,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                // Audio Compression Options
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Bitrate âm thanh mục tiêu",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            audioBitrates.forEach { br ->
                                FilterChip(
                                    selected = selectedAudioBitrate == br,
                                    onClick = { selectedAudioBitrate = br },
                                    label = { Text("${br} kbps") },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Định dạng sau khi nén:",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            FilterChip(
                                selected = audioTargetFormat == "m4a",
                                onClick = { audioTargetFormat = "m4a" },
                                label = { Text("M4A (AAC tối ưu nhất)") },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = audioTargetFormat == "mp3",
                                onClick = { audioTargetFormat = "mp3" },
                                label = { Text("MP3") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Estimate Summary Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Ước tính dung lượng",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Kích thước gốc: ${FileUtils.formatFileSize(selectedFileSize)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    val estimateText = if (isVideoInput) {
                        when (videoPresetIndex) {
                            0 -> "Dự kiến sau nén: ~${FileUtils.formatFileSize((selectedFileSize * 0.65).toLong())} (Giảm ~35%)"
                            1 -> "Dự kiến sau nén: ~${FileUtils.formatFileSize((selectedFileSize * 0.40).toLong())} (Giảm ~60%)"
                            else -> "Dự kiến sau nén: ~${FileUtils.formatFileSize((selectedFileSize * 0.20).toLong())} (Giảm ~80%)"
                        }
                    } else {
                        "Dự kiến sau nén: ~${FileUtils.formatFileSize((selectedFileSize * (selectedAudioBitrate / 192.0).coerceIn(0.2, 0.8)).toLong())}"
                    }
                    Text(
                        text = estimateText,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Action Button
            Button(
                onClick = {
                    val uri = selectedUri ?: return@Button
                    if (ProcessingManager.isRunning()) {
                        Toast.makeText(context, "Đang có tác vụ khác đang chạy!", Toast.LENGTH_SHORT).show()
                        return@Button
                    }

                    coroutineScope.launch {
                        val inputCache = withContext(Dispatchers.IO) {
                            FileUtils.copyUriToCache(context, uri, "comp_in")
                        }
                        if (inputCache == null) {
                            Toast.makeText(context, "Không thể đọc file từ bộ nhớ!", Toast.LENGTH_LONG).show()
                            return@launch
                        }

                        val baseName = selectedFileName.substringBeforeLast('.')

                        if (isVideoInput) {
                            val outputCache = FileUtils.createTempOutputFile(context, "comp_out", "mp4")
                            val targetDisplayName = "${baseName}_compressed_${System.currentTimeMillis()}.mp4"

                            val (targetHeight, vBitrate, aBitrate) = when (videoPresetIndex) {
                                0 -> Triple(1080, "4M", "128k")
                                1 -> Triple(720, "2M", "96k")
                                else -> Triple(480, "1M", "64k")
                            }

                            val args = FFmpegCommands.buildCompressVideoCommand(
                                inputPath = inputCache.absolutePath,
                                outputPath = outputCache.absolutePath,
                                targetHeight = targetHeight,
                                videoBitrate = vBitrate,
                                audioBitrate = aBitrate,
                                presetIndex = videoPresetIndex
                            )

                            ProcessingManager.runTask(
                                context = context,
                                taskTitle = "Nén Video (${targetHeight}p)",
                                inputCacheFile = inputCache,
                                outputCacheFile = outputCache,
                                isVideo = true,
                                targetDisplayName = targetDisplayName,
                                argsArray = args
                            )
                        } else {
                            val outputCache = FileUtils.createTempOutputFile(context, "comp_out", audioTargetFormat)
                            val targetDisplayName = "${baseName}_compressed_${System.currentTimeMillis()}.$audioTargetFormat"

                            val args = FFmpegCommands.buildCompressAudioCommand(
                                inputPath = inputCache.absolutePath,
                                outputPath = outputCache.absolutePath,
                                targetBitrateKbps = selectedAudioBitrate,
                                targetFormat = audioTargetFormat
                            )

                            ProcessingManager.runTask(
                                context = context,
                                taskTitle = "Nén âm thanh (${selectedAudioBitrate}k)",
                                inputCacheFile = inputCache,
                                outputCacheFile = outputCache,
                                isVideo = false,
                                targetDisplayName = targetDisplayName,
                                argsArray = args
                            )
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Compress, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isVideoInput) "Bắt đầu nén video" else "Bắt đầu nén âm thanh",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
