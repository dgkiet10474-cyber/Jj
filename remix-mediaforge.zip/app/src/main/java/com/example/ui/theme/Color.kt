package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Studio Flame & Amber Palette
val ForgeOrange = Color(0xFFFF6D00)
val ForgeOrangeLight = Color(0xFFFF9E40)
val ForgeOrangeDark = Color(0xFFC43E00)
val ForgeOrangeSubtle = Color(0x26FF6D00)

val ForgeAmber = Color(0xFFFFB300)
val ForgeAmberSubtle = Color(0x26FFB300)

// Accents
val CyanAccent = Color(0xFF00E5FF)
val CyanAccentDark = Color(0xFF00B0FF)
val CyanAccentSubtle = Color(0x2600E5FF)

val IndigoAccent = Color(0xFF6366F1)
val IndigoAccentSubtle = Color(0x266366F1)

val VioletAccent = Color(0xFF8B5CF6)
val EmeraldAccent = Color(0xFF10B981)
val RoseAccent = Color(0xFFF43F5E)

// Dark Theme Surfaces - Deep Modern Studio Theme
val DarkBg = Color(0xFF0B0B12)
val DarkSurface = Color(0xFF14131F)
val DarkSurfaceVariant = Color(0xFF1F1E2E)
val DarkSurfaceElevated = Color(0xFF28273B)
val DarkOnSurface = Color(0xFFF1F0F7)
val DarkOnSurfaceVariant = Color(0xFFA5A3BC)
val DarkOutline = Color(0xFF333148)
val DarkOutlineVariant = Color(0xFF232233)

// Light Theme Surfaces
val LightBg = Color(0xFFF8F9FD)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF0F8)
val LightSurfaceElevated = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF14141F)
val LightOnSurfaceVariant = Color(0xFF5A5B6E)
val LightOutline = Color(0xFFD6D8E4)
val LightOutlineVariant = Color(0xFFE5E7F0)

val SuccessGreen = Color(0xFF00C853)
val ErrorRed = Color(0xFFFF3D00)
