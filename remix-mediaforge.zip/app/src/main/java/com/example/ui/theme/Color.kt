package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Forge Flame & Amber
val ForgeOrange = Color(0xFFFF6D00)
val ForgeOrangeLight = Color(0xFFFF9E40)
val ForgeOrangeDark = Color(0xFFC43E00)

val ForgeAmber = Color(0xFFFFB300)
val CyanAccent = Color(0xFF00E5FF)
val CyanAccentDark = Color(0xFF00B0FF)

// Dark Theme Surfaces
val DarkBg = Color(0xFF12111A)
val DarkSurface = Color(0xFF1B1926)
val DarkSurfaceVariant = Color(0xFF28253B)
val DarkOnSurface = Color(0xFFEDE7F6)
val DarkOutline = Color(0xFF45405E)

// Light Theme Surfaces
val LightBg = Color(0xFFFBF8FF)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEDE7F6)
val LightOnSurface = Color(0xFF1B1B22)
val LightOutline = Color(0xFF79747E)

val SuccessGreen = Color(0xFF00C853)
val ErrorRed = Color(0xFFFF3D00)
