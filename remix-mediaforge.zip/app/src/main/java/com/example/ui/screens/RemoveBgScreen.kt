package com.example.ui.screens

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.StudioActionButton
import com.example.ui.components.StudioSectionHeader
import com.example.util.FileUtils
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

private const val TAG = "RemoveBgScreen"

// Cạnh dài tối đa của ảnh đưa vào mô hình (tránh tràn RAM với ảnh 12MP+)
private const val MAX_SIDE = 2048

private enum class BgOption(val label: String, val color: Color?) {
    TRANSPARENT("Trong suốt", null),
    WHITE("Trắng", Color.White),
    BLACK("Đen", Color.Black),
    GREEN("Xanh lá", Color(0xFF00B140)),
    BLUE("Xanh dương", Color(0xFF2563EB))
}

@Composable
fun RemoveBgScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedName by remember { mutableStateOf("") }
    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var resultBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isProcessing by remember { mutableStateOf(false) }
    var bgOption by remember { mutableStateOf(BgOption.TRANSPARENT) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val bmp = withContext(Dispatchers.IO) { decodeBitmap(context, uri) }
                if (bmp == null) {
                    Toast.makeText(context, "Không đọc được ảnh này", Toast.LENGTH_SHORT).show()
                } else {
                    selectedUri = uri
                    selectedName = FileUtils.getFileName(context, uri)
                    originalBitmap = bmp
                    resultBitmap = null
                    bgOption = BgOption.TRANSPARENT
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        StudioSectionHeader(title = "Chọn ảnh")

        StudioActionButton(
            text = if (selectedUri == null) "Chọn ảnh" else "Đổi ảnh khác",
            icon = Icons.Default.Image,
            enabled = !isProcessing,
            onClick = { picker.launch("image/*") }
        )

        val shown = resultBitmap ?: originalBitmap
        if (shown != null) {
            if (selectedName.isNotBlank()) {
                Text(
                    text = selectedName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Vùng xem trước: caro khi trong suốt, màu đặc khi chọn nền màu
            val showChecker = resultBitmap != null && bgOption.color == null
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(360.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .then(
                        if (resultBitmap != null && bgOption.color != null) {
                            Modifier.background(bgOption.color!!)
                        } else if (showChecker) {
                            Modifier.drawBehind { drawChecker() }
                        } else {
                            Modifier.background(MaterialTheme.colorScheme.surfaceVariant)
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    bitmap = shown.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
                if (isProcessing) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.45f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Color.White)
                            Spacer(Modifier.height(12.dp))
                            Text("Đang xoá nền...", color = Color.White)
                        }
                    }
                }
            }

            StudioActionButton(
                text = if (resultBitmap == null) "Xoá nền" else "Xoá nền lại",
                icon = Icons.Default.AutoFixHigh,
                enabled = !isProcessing && originalBitmap != null,
                onClick = {
                    val src = originalBitmap ?: return@StudioActionButton
                    scope.launch {
                        isProcessing = true
                        try {
                            val fg = removeBackground(src)
                            if (fg == null) {
                                Toast.makeText(
                                    context,
                                    "Không tìm thấy vật thể/người trong ảnh",
                                    Toast.LENGTH_LONG
                                ).show()
                            } else {
                                resultBitmap = fg
                            }
                        } catch (e: Throwable) {
                            Log.e(TAG, "Lỗi xoá nền: ${e.message}", e)
                            Toast.makeText(
                                context,
                                "Xoá nền lỗi: mô hình có thể đang tải (cần Internet lần đầu, " +
                                    "cần Google Play Services). Thử lại sau ít phút.",
                                Toast.LENGTH_LONG
                            ).show()
                        } finally {
                            isProcessing = false
                        }
                    }
                }
            )

            if (resultBitmap != null) {
                StudioSectionHeader(title = "Nền phía sau")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BgOption.values().forEach { opt ->
                        BgSwatch(
                            option = opt,
                            selected = bgOption == opt,
                            onClick = { bgOption = opt }
                        )
                    }
                }
                Text(
                    text = "Nền: ${bgOption.label}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                StudioActionButton(
                    text = "Lưu vào thư viện ảnh",
                    icon = Icons.Default.SaveAlt,
                    enabled = !isProcessing,
                    onClick = {
                        val fg = resultBitmap ?: return@StudioActionButton
                        scope.launch {
                            val uri = withContext(Dispatchers.IO) {
                                val out = composeOutput(fg, bgOption.color)
                                saveImageToGallery(context, out, buildOutputName(selectedName))
                            }
                            Toast.makeText(
                                context,
                                if (uri != null) "Đã lưu vào Pictures/MediaForge" else "Lưu ảnh thất bại",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                )

                StudioActionButton(
                    text = "Chia sẻ",
                    icon = Icons.Default.Share,
                    enabled = !isProcessing,
                    onClick = {
                        val fg = resultBitmap ?: return@StudioActionButton
                        scope.launch {
                            val file = withContext(Dispatchers.IO) {
                                val out = composeOutput(fg, bgOption.color)
                                val f = File(
                                    context.cacheDir,
                                    buildOutputName(selectedName)
                                )
                                FileOutputStream(f).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
                                f
                            }
                            FileUtils.shareFile(context, file)
                        }
                    }
                )
            }
        } else {
            Text(
                text = "Chọn một tấm ảnh có người hoặc đồ vật rõ ràng. App tự tách vật thể chính " +
                    "khỏi nền, chạy trên máy, không cần API key. Lần đầu dùng cần Internet để " +
                    "tải mô hình.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun BgSwatch(option: BgOption, selected: Boolean, onClick: () -> Unit) {
    val borderColor = if (selected) MaterialTheme.colorScheme.primary
    else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .then(
                if (option.color != null) Modifier.background(option.color)
                else Modifier.drawBehind { drawChecker(cell = 8.dp.toPx()) }
            )
            .border(if (selected) 3.dp else 1.dp, borderColor, CircleShape)
            .clickable(onClick = onClick)
    )
}

// Vẽ nền caro xám để biểu thị vùng trong suốt
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawChecker(cell: Float = 16.dp.toPx()) {
    val light = Color(0xFFEDEDED)
    val dark = Color(0xFFC9C9C9)
    var y = 0f
    var row = 0
    while (y < size.height) {
        var x = 0f
        var col = 0
        while (x < size.width) {
            drawRect(
                color = if ((row + col) % 2 == 0) light else dark,
                topLeft = Offset(x, y),
                size = Size(cell, cell)
            )
            x += cell
            col++
        }
        y += cell
        row++
    }
}

// Đọc ảnh, thu nhỏ nếu quá lớn và xoay theo EXIF
private fun decodeBitmap(context: Context, uri: Uri): Bitmap? {
    return try {
        val resolver = context.contentResolver

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE) sample *= 2

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val raw = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return null

        val orientation = try {
            resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }

        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
            else -> return raw
        }
        Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)
    } catch (e: Throwable) {
        Log.e(TAG, "Lỗi đọc ảnh: ${e.message}", e)
        null
    }
}

// Gọi ML Kit Subject Segmentation, trả về ảnh vật thể với nền trong suốt (null nếu không thấy vật thể)
private suspend fun removeBackground(source: Bitmap): Bitmap? {
    val options = SubjectSegmenterOptions.Builder()
        .enableForegroundBitmap()
        .build()
    val segmenter = SubjectSegmentation.getClient(options)
    try {
        val image = InputImage.fromBitmap(source, 0)
        return suspendCancellableCoroutine { cont ->
            segmenter.process(image)
                .addOnSuccessListener { result -> cont.resume(result.foregroundBitmap) }
                .addOnFailureListener { e -> cont.resumeWithException(e) }
        }
    } finally {
        segmenter.close()
    }
}

// Ghép vật thể lên nền màu (hoặc giữ trong suốt nếu color == null)
private fun composeOutput(fg: Bitmap, color: Color?): Bitmap {
    if (color == null) return fg
    val out = Bitmap.createBitmap(fg.width, fg.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(out)
    canvas.drawColor(android.graphics.Color.argb(
        (color.alpha * 255).toInt(),
        (color.red * 255).toInt(),
        (color.green * 255).toInt(),
        (color.blue * 255).toInt()
    ))
    canvas.drawBitmap(fg, 0f, 0f, null)
    return out
}

private fun buildOutputName(originalName: String): String {
    val base = originalName.substringBeforeLast('.', "image").ifBlank { "image" }
    return "${base}_nobg_${System.currentTimeMillis()}.png"
}

// Lưu PNG vào Pictures/MediaForge
private fun saveImageToGallery(context: Context, bitmap: Bitmap, fileName: String): Uri? {
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/MediaForge")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val uri = context.contentResolver.insert(collection, values) ?: return null
            context.contentResolver.openOutputStream(uri)?.use {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            context.contentResolver.update(uri, values, null, null)
            uri
        } else {
            @Suppress("DEPRECATION")
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "MediaForge"
            )
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, fileName)
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            android.media.MediaScannerConnection.scanFile(
                context, arrayOf(file.absolutePath), arrayOf("image/png"), null
            )
            Uri.fromFile(file)
        }
    } catch (e: Throwable) {
        Log.e(TAG, "Lỗi lưu ảnh: ${e.message}", e)
        null
    }
}
