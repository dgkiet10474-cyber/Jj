package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.arthenica.ffmpegkit.FFprobeKit
import com.example.engine.FFmpegCommands
import com.example.engine.ProcessingManager
import com.example.ui.components.MediaPreviewPlayer
import com.example.ui.components.StudioActionButton
import com.example.ui.components.StudioFilePickerCard
import com.example.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpeedScreen(targetMediaType: String? = null) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedFileName by remember { mutableStateOf("") }
    var selectedFileSize by remember { mutableLongStateOf(0L) }
    var isVideoInput by remember { mutableStateOf(targetMediaType != "audio") }

    // Speed: 0.25f to 4.0f
    var speed by remember { mutableFloatStateOf(1.25f) }
    var keepPitch by remember { mutableStateOf(true) }

    val quickSpeeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            selectedFileName = FileUtils.getFileName(context, uri)
            selectedFileSize = FileUtils.getFileSize(context, uri)
            val extension = selectedFileName.substringAfterLast('.', "").lowercase()
            val videoExts = listOf("mp4", "mkv", "mov", "avi", "webm", "flv", "3gp", "wmv", "m4v")
            isVideoInput = if (targetMediaType == "audio") false else if (targetMediaType == "video") true else (videoExts.contains(extension) || uri.toString().contains("video"))
        }
    }

    val targetMimes = when (targetMediaType) {
        "video" -> arrayOf("video/*")
        "audio" -> arrayOf("audio/*")
        else -> arrayOf("audio/*", "video/*")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // File Selection Card
        StudioFilePickerCard(
            selectedUri = selectedUri,
            selectedFileName = selectedFileName,
            selectedFileSize = selectedFileSize,
            isVideoInput = isVideoInput,
            onPickClick = { filePicker.launch(targetMimes) },
            previewContent = {
                if (selectedUri != null) {
                    MediaPreviewPlayer(
                        uri = selectedUri!!,
                        isVideo = isVideoInput
                    )
                }
            }
        )

        if (selectedUri != null) {
            // Speed Controls
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Tốc độ phát",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = String.format(Locale.US, "%.2fx", speed),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Slider(
                        value = speed,
                        onValueChange = { newVal ->
                            // Round to step 0.05
                            val stepped = (newVal * 20).roundToInt() / 20f
                            speed = stepped.coerceIn(0.25f, 4.0f)
                        },
                        valueRange = 0.25f..4.0f,
                        steps = 74, // (4.0 - 0.25) / 0.05 - 1 = 74 steps
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("0.25x (Rất chậm)", style = MaterialTheme.typography.labelSmall)
                        Text("1.0x (Chuẩn)", style = MaterialTheme.typography.labelSmall)
                        Text("4.0x (Cực nhanh)", style = MaterialTheme.typography.labelSmall)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quick buttons
                    Text(
                        text = "Chọn nhanh:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        quickSpeeds.forEach { qs ->
                            FilterChip(
                                selected = (speed - qs) in -0.01f..0.01f,
                                onClick = { speed = qs },
                                label = {
                                    Text(
                                        text = "${qs}x",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                },
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Pitch preservation option
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                            Text(
                                text = if (keepPitch) "Giữ nguyên cao độ giọng (atempo)" else "Đổi cả cao độ giọng (asetrate)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (keepPitch)
                                    "Giọng nói tự nhiên, không bị the thé khi tua nhanh hoặc ồm ồm khi làm chậm."
                                else
                                    "Hiệu ứng giọng sóc chuột (khi tăng tốc) hoặc giọng trầm ma quái (khi giảm tốc).",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = keepPitch,
                            onCheckedChange = { keepPitch = it }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Action Button
            StudioActionButton(
                text = "Áp dụng tốc độ ${String.format(Locale.US, "%.2fx", speed)}",
                icon = Icons.Default.Speed,
                enabled = selectedUri != null,
                onClick = {
                    val uri = selectedUri ?: return@StudioActionButton
                    if (ProcessingManager.isRunning()) {
                        Toast.makeText(context, "Đang có tác vụ khác đang chạy!", Toast.LENGTH_SHORT).show()
                        return@StudioActionButton
                    }

                    coroutineScope.launch {
                        val inputCache = withContext(Dispatchers.IO) {
                            FileUtils.copyUriToCache(context, uri, "speed_in")
                        }
                        if (inputCache == null) {
                            Toast.makeText(context, "Không thể đọc file từ bộ nhớ!", Toast.LENGTH_LONG).show()
                            return@launch
                        }

                        val baseName = selectedFileName.substringBeforeLast('.')
                        val ext = selectedFileName.substringAfterLast('.', if (isVideoInput) "mp4" else "m4a")
                        val speedStr = String.format(Locale.US, "%.2fx", speed)

                        // Lấy thông tin bitrate và fps gốc trên IO thread để tính toán GOP và bitrate tối ưu cho output
                        val (originalBitrateBps, outputFps) = withContext(Dispatchers.IO) {
                            if (isVideoInput) {
                                var probedBitrate: Long? = null
                                var fpsVal = 30
                                try {
                                    val mediaInfo = FFprobeKit.getMediaInformation(inputCache.absolutePath)?.mediaInformation
                                    if (mediaInfo != null) {
                                        probedBitrate = mediaInfo.bitrate?.toLongOrNull()
                                        if (probedBitrate == null || probedBitrate <= 0) {
                                            val dur = mediaInfo.duration?.toDoubleOrNull() ?: 0.0
                                            if (dur > 0) {
                                                probedBitrate = ((inputCache.length() * 8) / dur).toLong()
                                            }
                                        }
                                        val videoStream = mediaInfo.streams?.firstOrNull { it.type == "video" }
                                        val rFrameRate = videoStream?.realFrameRate
                                        if (rFrameRate != null && rFrameRate.contains("/")) {
                                            val parts = rFrameRate.split("/")
                                            val num = parts[0].toDoubleOrNull()
                                            val den = parts[1].toDoubleOrNull()
                                            if (num != null && den != null && den > 0) {
                                                val parsed = (num / den).toInt()
                                                if (parsed in 15..120) fpsVal = parsed
                                            }
                                        } else if (rFrameRate != null) {
                                            rFrameRate.toDoubleOrNull()?.toInt()?.let {
                                                if (it in 15..120) fpsVal = it
                                            }
                                        }
                                    }
                                } catch (_: Throwable) {}
                                Pair(probedBitrate, fpsVal)
                            } else {
                                Pair(null, 30)
                            }
                        }

                        val outputCache = FileUtils.createTempOutputFile(context, "speed_out", ext)
                        val targetDisplayName = "${baseName}_speed_${speedStr}_${System.currentTimeMillis()}.$ext"

                        val args = FFmpegCommands.buildSpeedCommand(
                            inputPath = inputCache.absolutePath,
                            outputPath = outputCache.absolutePath,
                            speed = speed,
                            isVideo = isVideoInput,
                            keepPitch = keepPitch,
                            originalBitrateBps = originalBitrateBps,
                            outputFps = outputFps
                        )

                        ProcessingManager.runTask(
                            context = context,
                            taskTitle = "Đổi tốc độ sang $speedStr",
                            inputCacheFile = inputCache,
                            outputCacheFile = outputCache,
                            isVideo = isVideoInput,
                            targetDisplayName = targetDisplayName,
                            argsArray = args,
                            durationDivisor = speed
                        )
                    }
                }
            )
        }
    }
}
