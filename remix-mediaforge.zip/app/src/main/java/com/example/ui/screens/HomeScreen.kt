package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class HomeAction {
    VIDEO_TO_AUDIO,
    AUDIO_TRIM,
    VIDEO_TRIM,
    VIDEO_CONVERT,
    VIDEO_SPEED,
    VIDEO_COMPRESS,
    VIDEO_REVERSE,
    AUDIO_CONVERT,
    AUDIO_SPEED,
    AUDIO_COMPRESS,
    AUDIO_REVERSE
}

@Composable
fun HomeScreen(
    onActionClick: (HomeAction) -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF0F172A), // Dark slate/navy
                        Color(0xFF0B132B),
                        Color(0xFF030712)
                    )
                )
            )
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // 1. TOP HERO SECTION: 1 thẻ lớn gradient bên trái + 2 thẻ nhỏ bên phải
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(195.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Thẻ lớn bên trái: Video đến Âm thanh (Gradient đỏ - cam)
            Box(
                modifier = Modifier
                    .weight(1.15f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color(0xFFFF3D00),
                                Color(0xFFFF6D00),
                                Color(0xFFFFA000)
                            )
                        )
                    )
                    .clickable { onActionClick(HomeAction.VIDEO_TO_AUDIO) }
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Audiotrack,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "Video đến\nÂm thanh",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            lineHeight = 24.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Trích xuất MP3, M4A, FLAC...",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                }
            }

            // 2 Thẻ nhỏ xếp dọc bên phải: Trình cắt Âm thanh & Trình cắt video
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(11.dp)
            ) {
                // Thẻ trên: Trình cắt Âm thanh
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    Color(0xFF4F46E5),
                                    Color(0xFF7C3AED)
                                )
                            )
                        )
                        .clickable { onActionClick(HomeAction.AUDIO_TRIM) }
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.22f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCut,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "Trình cắt",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                            Text(
                                text = "Âm thanh",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }

                // Thẻ dưới: Trình cắt video
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    Color(0xFF0284C7),
                                    Color(0xFF06B6D4)
                                )
                            )
                        )
                        .clickable { onActionClick(HomeAction.VIDEO_TRIM) }
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.22f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VideoFile,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "Trình cắt",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                            Text(
                                text = "Video",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        // 2. NHÓM "VIDEO"
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(4.dp)
                        .height(18.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color(0xFF38BDF8))
                )
                Text(
                    text = "VIDEO",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFFE2E8F0),
                    letterSpacing = 1.2.sp
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                FeatureCircleButton(
                    title = "Chuyển đổi\nVideo",
                    icon = Icons.Default.Transform,
                    iconTint = Color(0xFF38BDF8),
                    containerColor = Color(0xFF1E293B),
                    modifier = Modifier.weight(1f),
                    onClick = { onActionClick(HomeAction.VIDEO_CONVERT) }
                )
                FeatureCircleButton(
                    title = "Tốc độ\nVideo",
                    icon = Icons.Default.Speed,
                    iconTint = Color(0xFFFBBF24),
                    containerColor = Color(0xFF1E293B),
                    modifier = Modifier.weight(1f),
                    onClick = { onActionClick(HomeAction.VIDEO_SPEED) }
                )
                FeatureCircleButton(
                    title = "Bộ nén\nvideo",
                    icon = Icons.Default.Compress,
                    iconTint = Color(0xFF34D399),
                    containerColor = Color(0xFF1E293B),
                    modifier = Modifier.weight(1f),
                    onClick = { onActionClick(HomeAction.VIDEO_COMPRESS) }
                )
                FeatureCircleButton(
                    title = "Đảo ngược\nvideo",
                    icon = Icons.Default.FastRewind,
                    iconTint = Color(0xFFA78BFA),
                    containerColor = Color(0xFF1E293B),
                    modifier = Modifier.weight(1f),
                    onClick = { onActionClick(HomeAction.VIDEO_REVERSE) }
                )
            }
        }

        // 3. NHÓM "ÂM THANH"
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(4.dp)
                        .height(18.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color(0xFFFB923C))
                )
                Text(
                    text = "ÂM THANH",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFFE2E8F0),
                    letterSpacing = 1.2.sp
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                FeatureCircleButton(
                    title = "Chuyển đổi\nÂm thanh",
                    icon = Icons.Default.Audiotrack,
                    iconTint = Color(0xFFFB923C),
                    containerColor = Color(0xFF1E293B),
                    modifier = Modifier.weight(1f),
                    onClick = { onActionClick(HomeAction.AUDIO_CONVERT) }
                )
                FeatureCircleButton(
                    title = "Tốc độ\nÂm thanh",
                    icon = Icons.Default.Speed,
                    iconTint = Color(0xFFFBBF24),
                    containerColor = Color(0xFF1E293B),
                    modifier = Modifier.weight(1f),
                    onClick = { onActionClick(HomeAction.AUDIO_SPEED) }
                )
                FeatureCircleButton(
                    title = "Nén\nâm thanh",
                    icon = Icons.Default.Compress,
                    iconTint = Color(0xFF2DD4BF),
                    containerColor = Color(0xFF1E293B),
                    modifier = Modifier.weight(1f),
                    onClick = { onActionClick(HomeAction.AUDIO_COMPRESS) }
                )
                FeatureCircleButton(
                    title = "Đảo ngược\nâm thanh",
                    icon = Icons.Default.FastRewind,
                    iconTint = Color(0xFFF472B6),
                    containerColor = Color(0xFF1E293B),
                    modifier = Modifier.weight(1f),
                    onClick = { onActionClick(HomeAction.AUDIO_REVERSE) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun FeatureCircleButton(
    title: String,
    icon: ImageVector,
    iconTint: Color,
    containerColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .padding(horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(containerColor)
                .border(1.dp, Color(0xFF334155), CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconTint,
                modifier = Modifier.size(28.dp)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFFCBD5E1),
            textAlign = TextAlign.Center,
            fontWeight = FontWeight.Medium,
            maxLines = 2,
            lineHeight = 14.sp
        )
    }
}
