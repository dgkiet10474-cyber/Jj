package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.EncoderDetector
import com.example.engine.FFmpegCommands
import com.example.engine.ProcessingManager
import com.example.ui.components.MediaPreviewPlayer
import com.example.ui.components.StudioActionButton
import com.example.ui.components.StudioFilePickerCard
import com.example.ui.components.StudioSectionHeader
import com.example.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConvertScreen(
    initialMode: Int = 0,
    filterVideoInputOnly: Boolean = false
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedFileName by remember { mutableStateOf("") }
    var selectedFileSize by remember { mutableLongStateOf(0L) }
    var isVideoInput by remember { mutableStateOf(false) }

    // Mode: 0 = Chuyển sang Audio, 1 = Chuyển video -> MP4
    var convertMode by remember { mutableIntStateOf(initialMode) }
    var stripMetadata by remember { mutableStateOf(true) }

    // Audio format options
    val audioFormats = listOf("mp3", "wav", "m4a", "aac", "flac", "ogg", "opus", "wma", "aiff", "amr")
    var selectedFormat by remember { mutableStateOf("mp3") }

    // Bitrate options
    val bitrates = listOf(64, 128, 192, 256, 320)
    var selectedBitrate by remember { mutableIntStateOf(192) }

    // Sample rate options: null = keep
    val sampleRates = listOf(null to "Giữ nguyên", 44100 to "44.1 kHz", 48000 to "48.0 kHz")
    var selectedSampleRate by remember { mutableStateOf<Int?>(null) }

    // Channel options: null = keep, 1 = Mono, 2 = Stereo
    val channelOptions = listOf(null to "Giữ nguyên", 1 to "Mono (1 kênh)", 2 to "Stereo (2 kênh)")
    var selectedChannel by remember { mutableStateOf<Int?>(null) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            selectedFileName = FileUtils.getFileName(context, uri)
            selectedFileSize = FileUtils.getFileSize(context, uri)
            val extension = selectedFileName.substringAfterLast('.', "").lowercase()
            val videoExts = listOf("mp4", "mkv", "mov", "avi", "webm", "flv", "3gp", "wmv", "m4v")
            isVideoInput = videoExts.contains(extension) || uri.toString().contains("video")
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Mode Selector Tabs
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            SegmentedButton(
                selected = convertMode == 0,
                onClick = { convertMode = 0 },
                shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
            ) {
                Text("Trích xuất / Đổi âm thanh")
            }
            SegmentedButton(
                selected = convertMode == 1,
                onClick = { convertMode = 1 },
                shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
            ) {
                Text("Video sang MP4")
            }
        }

        // File Selection Card
        StudioFilePickerCard(
            selectedUri = selectedUri,
            selectedFileName = selectedFileName,
            selectedFileSize = selectedFileSize,
            isVideoInput = isVideoInput,
            onPickClick = {
                val targetMimes = if (filterVideoInputOnly || convertMode == 1) {
                    arrayOf("video/*")
                } else {
                    arrayOf("audio/*", "video/*")
                }
                filePicker.launch(targetMimes)
            },
            previewContent = {
                if (selectedUri != null) {
                    MediaPreviewPlayer(
                        uri = selectedUri!!,
                        isVideo = isVideoInput
                    )
                }
            }
        )

        if (convertMode == 0) {
            // Định dạng đầu ra
            Text(
                text = "Định dạng âm thanh đầu ra (10 định dạng)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(audioFormats) { fmt ->
                    FilterChip(
                        selected = selectedFormat == fmt,
                        onClick = { selectedFormat = fmt },
                        label = { Text(fmt.uppercase()) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
            }

            // AMR notice if AMR is selected
            if (selectedFormat == "amr" && !EncoderDetector.hasAmrNb) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Lưu ý: Thiết bị hoặc bản build hiện tại có thể không hỗ trợ codec AMR (libopencore_amrnb). MediaForge sẽ thử nghiệm chuyển đổi.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Bitrate selection
            val isLossy = listOf("mp3", "m4a", "aac", "ogg", "opus", "wma").contains(selectedFormat)
            if (isLossy) {
                Text(
                    text = "Tốc độ bit âm thanh (Bitrate)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    bitrates.forEach { br ->
                        FilterChip(
                            selected = selectedBitrate == br,
                            onClick = { selectedBitrate = br },
                            label = {
                                Text(
                                    text = "${br}k",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Sample Rate
            Text(
                text = "Tần số lấy mẫu (Sample Rate)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                sampleRates.forEachIndexed { index, (rate, label) ->
                    SegmentedButton(
                        selected = selectedSampleRate == rate,
                        onClick = { selectedSampleRate = rate },
                        shape = SegmentedButtonDefaults.itemShape(index = index, count = sampleRates.size)
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Audio Channels
            Text(
                text = "Kênh âm thanh (Channels)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                channelOptions.forEachIndexed { index, (chan, label) ->
                    SegmentedButton(
                        selected = selectedChannel == chan,
                        onClick = { selectedChannel = chan },
                        shape = SegmentedButtonDefaults.itemShape(index = index, count = channelOptions.size)
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Xoá toàn bộ metadata Switch
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Xoá toàn bộ metadata",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Bảo mật & sạch sẽ: loại bỏ ID3, bìa album, thẻ tag và thông tin thiết bị",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = stripMetadata,
                        onCheckedChange = { stripMetadata = it }
                    )
                }
            }

        } else {
            // Chuyển video -> MP4
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Chuyển đổi định dạng Video sang MP4",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Hệ thống tự động sử dụng bộ mã hóa ${EncoderDetector.getBestVideoEncoder()} để tối ưu tốc độ và chất lượng tương thích mọi thiết bị.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Action Button
        StudioActionButton(
            text = if (convertMode == 0) "Bắt đầu chuyển đổi âm thanh" else "Bắt đầu chuyển sang MP4",
            icon = Icons.Default.Transform,
            enabled = selectedUri != null,
            onClick = {
                val uri = selectedUri
                if (uri == null) {
                    Toast.makeText(context, "Vui lòng chọn file trước!", Toast.LENGTH_SHORT).show()
                    return@StudioActionButton
                }

                if (ProcessingManager.isRunning()) {
                    Toast.makeText(context, "Đang có tác vụ khác đang chạy!", Toast.LENGTH_SHORT).show()
                    return@StudioActionButton
                }

                coroutineScope.launch {
                    val inputCache = withContext(Dispatchers.IO) {
                        FileUtils.copyUriToCache(context, uri, "conv_in")
                    }
                    if (inputCache == null) {
                        Toast.makeText(context, "Không thể đọc file từ bộ nhớ!", Toast.LENGTH_LONG).show()
                        return@launch
                    }

                    val baseName = selectedFileName.substringBeforeLast('.')
                    if (convertMode == 0) {
                        // Xuất sang Audio
                        val outputCache = FileUtils.createTempOutputFile(context, "conv_out", selectedFormat)
                        val targetDisplayName = "${baseName}_convert_${System.currentTimeMillis()}.$selectedFormat"

                        val args = FFmpegCommands.buildConvertAudioCommand(
                            inputPath = inputCache.absolutePath,
                            outputPath = outputCache.absolutePath,
                            format = selectedFormat,
                            bitrateKbps = selectedBitrate,
                            sampleRate = selectedSampleRate,
                            channels = selectedChannel,
                            stripMetadata = stripMetadata
                        )

                        ProcessingManager.runTask(
                            context = context,
                            taskTitle = "Chuyển đổi sang ${selectedFormat.uppercase()}",
                            inputCacheFile = inputCache,
                            outputCacheFile = outputCache,
                            isVideo = false,
                            targetDisplayName = targetDisplayName,
                            argsArray = args
                        )
                    } else {
                        // Chuyển Video sang MP4
                        val outputCache = FileUtils.createTempOutputFile(context, "conv_out", "mp4")
                        val targetDisplayName = "${baseName}_mp4_${System.currentTimeMillis()}.mp4"

                        val args = FFmpegCommands.buildConvertVideoToMp4Command(
                            inputPath = inputCache.absolutePath,
                            outputPath = outputCache.absolutePath
                        )

                        ProcessingManager.runTask(
                            context = context,
                            taskTitle = "Chuyển video sang MP4",
                            inputCacheFile = inputCache,
                            outputCacheFile = outputCache,
                            isVideo = true,
                            targetDisplayName = targetDisplayName,
                            argsArray = args
                        )
                    }
                }
            }
        )
    }
}
