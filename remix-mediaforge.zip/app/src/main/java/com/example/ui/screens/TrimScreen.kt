package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.FFmpegCommands
import com.example.engine.ProcessingManager
import com.example.ui.components.MediaPreviewPlayer
import com.example.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrimScreen(mediaType: String = "all") {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedFileName by remember { mutableStateOf("") }
    var selectedFileSize by remember { mutableLongStateOf(0L) }
    var isVideoInput by remember { mutableStateOf(mediaType == "video") }

    // Start / End in milliseconds
    var startMs by remember { mutableLongStateOf(0L) }
    var endMs by remember { mutableLongStateOf(10000L) }
    var totalDurationMs by remember { mutableLongStateOf(30000L) }

    // Text inputs for precise editing
    var startText by remember { mutableStateOf("00:00:00.000") }
    var endText by remember { mutableStateOf("00:00:10.000") }

    // Video trim mode: true = Cắt nhanh (-c copy), false = Cắt chính xác (re-encode)
    var fastCopy by remember { mutableStateOf(true) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            selectedFileName = FileUtils.getFileName(context, uri)
            selectedFileSize = FileUtils.getFileSize(context, uri)
            val extension = selectedFileName.substringAfterLast('.', "").lowercase()
            val videoExts = listOf("mp4", "mkv", "mov", "avi", "webm", "flv", "3gp", "wmv", "m4v")
            isVideoInput = if (mediaType == "audio") false else if (mediaType == "video") true else (videoExts.contains(extension) || uri.toString().contains("video"))

            // Reset start/end defaults
            startMs = 0L
            startText = "00:00:00.000"
            endMs = 15000L
            endText = "00:00:15.000"
        }
    }

    val targetMimes = when (mediaType) {
        "audio" -> arrayOf("audio/*")
        "video" -> arrayOf("video/*")
        else -> arrayOf("audio/*", "video/*")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // File selection card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isVideoInput) Icons.Default.VideoFile else Icons.Default.Audiotrack,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (selectedUri != null) {
                                if (isVideoInput) "Video cần cắt" else "Âm thanh cần cắt"
                            } else {
                                when (mediaType) {
                                    "audio" -> "Chưa chọn file âm thanh"
                                    "video" -> "Chưa chọn video"
                                    else -> "Chưa chọn file"
                                }
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = { filePicker.launch(targetMimes) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Chọn file")
                    }
                }

                if (selectedUri != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = selectedFileName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Dung lượng: ${FileUtils.formatFileSize(selectedFileSize)} • ${if (isVideoInput) "Video" else "Âm thanh"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    MediaPreviewPlayer(
                        uri = selectedUri!!,
                        isVideo = isVideoInput,
                        onSetStart = { pos ->
                            startMs = pos
                            startText = FileUtils.formatDurationDetailed(pos)
                        },
                        onSetEnd = { pos ->
                            endMs = pos
                            endText = FileUtils.formatDurationDetailed(pos)
                        }
                    )
                }
            }
        }

        if (selectedUri != null) {
            // Trim Range Controls
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Khoảng thời gian cắt",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = startText,
                            onValueChange = {
                                startText = it
                                FileUtils.parseDurationToMs(it)?.let { ms -> startMs = ms }
                            },
                            label = { Text("Bắt đầu (hh:mm:ss.SSS)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = endText,
                            onValueChange = {
                                endText = it
                                FileUtils.parseDurationToMs(it)?.let { ms -> endMs = ms }
                            },
                            label = { Text("Kết thúc (hh:mm:ss.SSS)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val clipDurationMs = (endMs - startMs).coerceAtLeast(0L)
                    Text(
                        text = "Thời lượng đoạn cắt: ${FileUtils.formatDurationDetailed(clipDurationMs)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )

                    // Error warning
                    if (endMs <= startMs) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Cảnh báo: Thời gian kết thúc phải lớn hơn thời gian bắt đầu!",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Video Mode: Cắt nhanh vs Cắt chính xác
            if (isVideoInput) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Chế độ cắt video",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (fastCopy) "Cắt nhanh (-c copy)" else "Cắt chính xác (Re-encode)",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (fastCopy)
                                        "Xuất cực nhanh, không giảm chất lượng, có thể lệch vài giây do keyframe."
                                    else
                                        "Cắt khớp từng mili-giây, mã hóa lại video bằng bộ xử lý phần cứng.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = fastCopy,
                                onCheckedChange = { fastCopy = it }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Action Button
            Button(
                onClick = {
                    val uri = selectedUri ?: return@Button
                    if (endMs <= startMs) {
                        Toast.makeText(context, "Thời gian kết thúc phải lớn hơn bắt đầu!", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (ProcessingManager.isRunning()) {
                        Toast.makeText(context, "Đang có tác vụ khác đang chạy!", Toast.LENGTH_SHORT).show()
                        return@Button
                    }

                    coroutineScope.launch {
                        val inputCache = withContext(Dispatchers.IO) {
                            FileUtils.copyUriToCache(context, uri, "trim_in")
                        }
                        if (inputCache == null) {
                            Toast.makeText(context, "Không thể đọc file từ bộ nhớ!", Toast.LENGTH_LONG).show()
                            return@launch
                        }

                        val baseName = selectedFileName.substringBeforeLast('.')
                        val ext = selectedFileName.substringAfterLast('.', if (isVideoInput) "mp4" else "mp3")

                        val outputCache = FileUtils.createTempOutputFile(context, "trim_out", ext)
                        val targetDisplayName = "${baseName}_trim_${System.currentTimeMillis()}.$ext"

                        val startSec = startMs / 1000.0
                        val endSec = endMs / 1000.0

                        val args = if (isVideoInput) {
                            FFmpegCommands.buildTrimVideoCommand(
                                inputPath = inputCache.absolutePath,
                                outputPath = outputCache.absolutePath,
                                startSec = startSec,
                                endSec = endSec,
                                fastCopy = fastCopy
                            )
                        } else {
                            FFmpegCommands.buildTrimAudioCommand(
                                inputPath = inputCache.absolutePath,
                                outputPath = outputCache.absolutePath,
                                startSec = startSec,
                                endSec = endSec,
                                format = ext
                            )
                        }

                        ProcessingManager.runTask(
                            context = context,
                            taskTitle = if (isVideoInput) "Cắt video" else "Cắt âm thanh",
                            inputCacheFile = inputCache,
                            outputCacheFile = outputCache,
                            isVideo = isVideoInput,
                            targetDisplayName = targetDisplayName,
                            argsArray = args
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.ContentCut, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isVideoInput) "Bắt đầu cắt video" else "Bắt đầu cắt âm thanh",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
