package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.ExportedMediaFile
import com.example.util.FileUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OutputFilesScreen(
    files: List<ExportedMediaFile>,
    isSelectionMode: Boolean,
    selectedUris: Set<Uri>,
    onToggleSelect: (ExportedMediaFile) -> Unit,
    onRefresh: () -> Unit
) {
    val context = LocalContext.current

    // State for single-file options bottom sheet
    var activeFileForOptions by remember { mutableStateOf<ExportedMediaFile?>(null) }
    var fileToDeleteSingle by remember { mutableStateOf<ExportedMediaFile?>(null) }

    val totalSizeBytes = remember(files) { files.sumOf { it.sizeBytes } }
    val selectedFiles = remember(files, selectedUris) { files.filter { selectedUris.contains(it.uri) } }
    val selectedSizeBytes = remember(selectedFiles) { selectedFiles.sumOf { it.sizeBytes } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 1. Thanh tóm tắt tổng dung lượng & trạng thái chọn
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surfaceVariant,
            tonalElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Tổng: ${files.size} file • ${FileUtils.formatFileSize(totalSizeBytes)}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (isSelectionMode) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Đã chọn: ${selectedUris.size} file • ${FileUtils.formatFileSize(selectedSizeBytes)}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                if (isSelectionMode) {
                    SuggestionChip(
                        onClick = { /* Đang trong chế độ chọn */ },
                        label = { Text("Chế độ chọn", style = MaterialTheme.typography.labelSmall) },
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            labelColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    )
                }
            }
        }

        // 2. Danh sách file hoặc trạng thái rỗng
        if (files.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.FolderOpen,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.size(44.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Chưa có file nào",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Các file video hoặc âm thanh sau khi được chuyển đổi, cắt, nén sẽ xuất hiện tại đây.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(files, key = { it.uri.toString() }) { fileItem ->
                    val isChecked = selectedUris.contains(fileItem.uri)

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (isSelectionMode) {
                                    onToggleSelect(fileItem)
                                } else {
                                    activeFileForOptions = fileItem
                                }
                            },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelectionMode && isChecked) {
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                            } else {
                                MaterialTheme.colorScheme.surface
                            }
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isSelectionMode) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { onToggleSelect(fileItem) },
                                    modifier = Modifier.padding(end = 8.dp)
                                )
                            }

                            // Icon loại file
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (fileItem.isVideo) Color(0xFF0284C7).copy(alpha = 0.15f)
                                        else Color(0xFFFF5722).copy(alpha = 0.15f)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (fileItem.isVideo) Icons.Default.VideoFile else Icons.Default.Audiotrack,
                                    contentDescription = null,
                                    tint = if (fileItem.isVideo) Color(0xFF0284C7) else Color(0xFFFF5722),
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            // Thông tin file
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = fileItem.name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    // Tag định dạng (MP4, MP3,...)
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant
                                    ) {
                                        Text(
                                            text = fileItem.extension,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp),
                                            fontSize = 10.sp
                                        )
                                    }

                                    Text(
                                        text = FileUtils.formatFileSize(fileItem.sizeBytes),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    Text(
                                        text = "•",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    Text(
                                        text = FileUtils.formatDate(fileItem.dateAddedSec),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            if (!isSelectionMode) {
                                IconButton(onClick = { activeFileForOptions = fileItem }) {
                                    Icon(
                                        imageVector = Icons.Default.MoreVert,
                                        contentDescription = "Tuỳ chọn",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal BottomSheet tuỳ chọn khi chạm 1 file ở chế độ thường
    if (activeFileForOptions != null) {
        val target = activeFileForOptions!!
        ModalBottomSheet(
            onDismissRequest = { activeFileForOptions = null },
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp)
            ) {
                // Header file info
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (target.isVideo) Color(0xFF0284C7).copy(alpha = 0.15f)
                                else Color(0xFFFF5722).copy(alpha = 0.15f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (target.isVideo) Icons.Default.VideoFile else Icons.Default.Audiotrack,
                            contentDescription = null,
                            tint = if (target.isVideo) Color(0xFF0284C7) else Color(0xFFFF5722),
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = target.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${FileUtils.formatFileSize(target.sizeBytes)} • ${FileUtils.formatDate(target.dateAddedSec)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(8.dp))

                // Mục "Mở"
                ListItem(
                    headlineContent = { Text("Mở file", fontWeight = FontWeight.SemiBold) },
                    leadingContent = { Icon(Icons.Default.OpenInNew, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                    modifier = Modifier.clickable {
                        activeFileForOptions = null
                        FileUtils.openExportedFile(context, target)
                    }
                )

                // Mục "Chia sẻ"
                ListItem(
                    headlineContent = { Text("Chia sẻ", fontWeight = FontWeight.SemiBold) },
                    leadingContent = { Icon(Icons.Default.Share, contentDescription = null, tint = MaterialTheme.colorScheme.secondary) },
                    modifier = Modifier.clickable {
                        activeFileForOptions = null
                        FileUtils.shareExportedFiles(context, listOf(target))
                    }
                )

                // Mục "Xoá"
                ListItem(
                    headlineContent = { Text("Xoá file", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold) },
                    leadingContent = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                    modifier = Modifier.clickable {
                        val fileToDelete = target
                        activeFileForOptions = null
                        fileToDeleteSingle = fileToDelete
                    }
                )

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // Hộp thoại xác nhận xoá 1 file
    if (fileToDeleteSingle != null) {
        val target = fileToDeleteSingle!!
        AlertDialog(
            onDismissRequest = { fileToDeleteSingle = null },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Xác nhận xoá file") },
            text = {
                Text("Bạn có chắc chắn muốn xoá vĩnh viễn file \"${target.name}\" khỏi thiết bị không?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val success = FileUtils.deleteExportedMediaFile(context, target)
                        fileToDeleteSingle = null
                        onRefresh()
                        if (success) {
                            Toast.makeText(context, "Đã xoá file thành công", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Không thể xoá file", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Xoá")
                }
            },
            dismissButton = {
                TextButton(onClick = { fileToDeleteSingle = null }) {
                    Text("Huỷ")
                }
            }
        )
    }
}
