package com.example.engine

import java.util.Locale

object FFmpegCommands {

    fun stripMetadataArgs(format: String): List<String> {
        val list = mutableListOf(
            "-map_metadata", "-1",
            "-map_chapters", "-1",
            "-fflags", "+bitexact",
            "-flags:a", "+bitexact"
        )
        val ext = format.lowercase()
        if (ext == "mp3") {
            list.add("-id3v2_version")
            list.add("0")
            list.add("-write_id3v1")
            list.add("0")
        }
        return list
    }

    fun buildConvertAudioCommand(
        inputPath: String,
        outputPath: String,
        format: String,
        bitrateKbps: Int = 192,
        sampleRate: Int? = null,
        channels: Int? = null,
        useFallbackMp3ToM4a: Boolean = false,
        stripMetadata: Boolean = true
    ): Array<String> {
        val args = mutableListOf<String>()
        args.add("-y")
        args.add("-i")
        args.add(inputPath)
        args.add("-vn") // Bỏ luồng video
        args.add("-map")
        args.add("0:a") // Chỉ lấy luồng âm thanh, bỏ ảnh bìa / stream phụ

        val lowerFormat = format.lowercase()
        when (lowerFormat) {
            "mp3" -> {
                if (EncoderDetector.hasMp3Lame && !useFallbackMp3ToM4a) {
                    args.add("-c:a")
                    args.add("libmp3lame")
                    args.add("-b:a")
                    args.add("${bitrateKbps}k")
                } else {
                    // Fallback to AAC (m4a)
                    args.add("-c:a")
                    args.add("aac")
                    args.add("-b:a")
                    args.add("${bitrateKbps}k")
                }
            }
            "wav" -> {
                args.add("-c:a")
                args.add("pcm_s16le")
            }
            "m4a" -> {
                args.add("-c:a")
                args.add("aac")
                args.add("-b:a")
                args.add("${bitrateKbps}k")
            }
            "aac" -> {
                args.add("-c:a")
                args.add("aac")
                args.add("-b:a")
                args.add("${bitrateKbps}k")
                args.add("-f")
                args.add("adts")
            }
            "flac" -> {
                args.add("-c:a")
                args.add("flac")
            }
            "ogg" -> {
                if (EncoderDetector.hasLibVorbis) {
                    args.add("-c:a")
                    args.add("libvorbis")
                } else {
                    args.add("-c:a")
                    args.add("vorbis")
                    args.add("-strict")
                    args.add("-2")
                }
                args.add("-b:a")
                args.add("${bitrateKbps}k")
            }
            "opus" -> {
                args.add("-c:a")
                args.add("libopus")
                args.add("-b:a")
                args.add("${bitrateKbps}k")
            }
            "wma" -> {
                args.add("-c:a")
                args.add("wmav2")
                args.add("-b:a")
                args.add("${bitrateKbps}k")
            }
            "aiff" -> {
                args.add("-c:a")
                args.add("pcm_s16be")
                args.add("-f")
                args.add("aiff")
            }
            "amr" -> {
                args.add("-c:a")
                args.add("libopencore_amrnb")
                args.add("-ar")
                args.add("8000")
                args.add("-ac")
                args.add("1")
                args.add("-b:a")
                args.add("12.2k")
            }
            else -> {
                args.add("-c:a")
                args.add("aac")
                args.add("-b:a")
                args.add("${bitrateKbps}k")
            }
        }

        // Sample rate (nếu chọn)
        if (sampleRate != null && lowerFormat != "amr") {
            args.add("-ar")
            args.add(sampleRate.toString())
        }

        // Kênh âm thanh (mono / stereo)
        if (channels != null && lowerFormat != "amr") {
            args.add("-ac")
            args.add(channels.toString())
        }

        // Xoá toàn bộ metadata nếu được bật (đặt TRƯỚC file output)
        if (stripMetadata) {
            args.addAll(stripMetadataArgs(lowerFormat))
        }

        // Với m4a/mp4 thêm -movflags +faststart
        if (lowerFormat == "m4a" || lowerFormat == "mp4") {
            args.add("-movflags")
            args.add("+faststart")
        }

        args.add(outputPath)
        return args.toTypedArray()
    }

    fun buildConvertVideoToMp4Command(
        inputPath: String,
        outputPath: String,
        videoEncoder: String = EncoderDetector.getBestVideoEncoder()
    ): Array<String> {
        return arrayOf(
            "-y",
            "-i", inputPath,
            "-vf", "format=yuv420p",
            "-c:v", videoEncoder,
            "-c:a", "aac",
            "-vsync", "2",
            "-async", "1",
            "-movflags", "+faststart",
            outputPath
        )
    }

    fun buildTrimAudioCommand(
        inputPath: String,
        outputPath: String,
        startSec: Double,
        endSec: Double,
        format: String = "mp3",
        stripMetadata: Boolean = true
    ): Array<String> {
        val startStr = String.format(Locale.US, "%.3f", startSec)
        val endStr = String.format(Locale.US, "%.3f", endSec)

        val args = mutableListOf<String>()
        args.add("-y")
        // Đặt -ss trước -i cho tốc độ tìm kiếm nhanh
        args.add("-ss")
        args.add(startStr)
        args.add("-to")
        args.add(endStr)
        args.add("-i")
        args.add(inputPath)
        args.add("-vn")
        args.add("-map")
        args.add("0:a")

        val ext = format.lowercase()
        when (ext) {
            "wav" -> {
                args.add("-c:a")
                args.add("pcm_s16le")
            }
            "m4a", "aac" -> {
                args.add("-c:a")
                args.add("aac")
                args.add("-b:a")
                args.add("192k")
            }
            "mp3" -> {
                if (EncoderDetector.hasMp3Lame) {
                    args.add("-c:a")
                    args.add("libmp3lame")
                    args.add("-b:a")
                    args.add("192k")
                } else {
                    args.add("-c:a")
                    args.add("aac")
                    args.add("-b:a")
                    args.add("192k")
                }
            }
            else -> {
                args.add("-c:a")
                args.add("aac")
                args.add("-b:a")
                args.add("192k")
            }
        }

        if (stripMetadata) {
            args.addAll(stripMetadataArgs(ext))
        }

        if (ext == "m4a" || ext == "mp4") {
            args.add("-movflags")
            args.add("+faststart")
        }

        args.add(outputPath)
        return args.toTypedArray()
    }

    fun buildTrimVideoCommand(
        inputPath: String,
        outputPath: String,
        startSec: Double,
        endSec: Double,
        fastCopy: Boolean,
        videoEncoder: String = EncoderDetector.getBestVideoEncoder()
    ): Array<String> {
        val startStr = String.format(Locale.US, "%.3f", startSec)
        val endStr = String.format(Locale.US, "%.3f", endSec)

        return if (fastCopy) {
            // Cắt nhanh: -c copy
            arrayOf(
                "-y",
                "-ss", startStr,
                "-to", endStr,
                "-i", inputPath,
                "-c", "copy",
                "-avoid_negative_ts", "1",
                outputPath
            )
        } else {
            // Cắt chính xác: re-encode
            arrayOf(
                "-y",
                "-ss", startStr,
                "-to", endStr,
                "-i", inputPath,
                "-vf", "format=yuv420p",
                "-c:v", videoEncoder,
                "-c:a", "aac",
                "-vsync", "2",
                "-async", "1",
                "-movflags", "+faststart",
                outputPath
            )
        }
    }

    fun buildCompressAudioCommand(
        inputPath: String,
        outputPath: String,
        targetBitrateKbps: Int = 64,
        targetFormat: String = "m4a"
    ): Array<String> {
        val args = mutableListOf<String>()
        args.add("-y")
        args.add("-i")
        args.add(inputPath)
        args.add("-vn")
        args.add("-map")
        args.add("0:a")

        val ext = targetFormat.lowercase()
        if (ext == "mp3" && EncoderDetector.hasMp3Lame) {
            args.add("-c:a")
            args.add("libmp3lame")
        } else {
            args.add("-c:a")
            args.add("aac")
        }
        args.add("-b:a")
        args.add("${targetBitrateKbps}k")
        args.add(outputPath)
        return args.toTypedArray()
    }

    fun buildCompressVideoCommand(
        inputPath: String,
        outputPath: String,
        targetHeight: Int,
        videoBitrate: String,
        audioBitrate: String,
        videoEncoder: String = EncoderDetector.getBestVideoEncoder()
    ): Array<String> {
        // format=yuv420p chuẩn hoá dải màu; scale flags=lanczos làm nét ảnh khi downscale sâu
        val filter = "format=yuv420p,scale=-2:$targetHeight:flags=lanczos"
        return arrayOf(
            "-y",
            "-i", inputPath,
            "-vf", filter,
            "-c:v", videoEncoder,
            "-b:v", videoBitrate,
            "-c:a", "aac",
            "-b:a", audioBitrate,
            "-vsync", "2",
            "-async", "1",
            "-movflags", "+faststart",
            outputPath
        )
    }

    fun buildAtempoFilter(speed: Float): String {
        var current = speed.toDouble()
        val filters = mutableListOf<String>()
        while (current > 2.0) {
            filters.add("atempo=2.0")
            current /= 2.0
        }
        while (current < 0.5) {
            filters.add("atempo=0.5")
            current /= 0.5
        }
        filters.add(String.format(Locale.US, "atempo=%.4f", current))
        return filters.joinToString(",")
    }

    fun buildSpeedCommand(
        inputPath: String,
        outputPath: String,
        speed: Float,
        isVideo: Boolean,
        keepPitch: Boolean,
        videoEncoder: String = EncoderDetector.getBestVideoEncoder()
    ): Array<String> {
        val audioFilter = if (keepPitch) {
            buildAtempoFilter(speed)
        } else {
            // Đổi cả cao độ: asetrate + aresample
            val sampleRate = 44100
            val targetRate = (sampleRate * speed).toInt()
            "asetrate=$targetRate,aresample=$sampleRate"
        }

        return if (isVideo) {
            val videoFilter = String.format(Locale.US, "setpts=PTS/%.4f", speed)
            val filterComplex = "[0:v]format=yuv420p,$videoFilter[v];[0:a]$audioFilter[a]"
            arrayOf(
                "-y",
                "-i", inputPath,
                "-filter_complex", filterComplex,
                "-map", "[v]",
                "-map", "[a]",
                "-c:v", videoEncoder,
                "-c:a", "aac",
                "-vsync", "2",
                "-async", "1",
                "-movflags", "+faststart",
                outputPath
            )
        } else {
            val ext = outputPath.substringAfterLast('.', "m4a").lowercase()
            val args = mutableListOf<String>()
            args.add("-y")
            args.add("-i")
            args.add(inputPath)
            args.add("-vn")
            args.add("-map")
            args.add("0:a")
            args.add("-af")
            args.add(audioFilter)
            if (ext == "mp3" && EncoderDetector.hasMp3Lame) {
                args.add("-c:a")
                args.add("libmp3lame")
            } else {
                args.add("-c:a")
                args.add("aac")
            }
            args.add("-b:a")
            args.add("192k")
            args.add(outputPath)
            args.toTypedArray()
        }
    }

    fun buildReverseCommand(
        inputPath: String,
        outputPath: String,
        isVideo: Boolean,
        videoEncoder: String = EncoderDetector.getBestVideoEncoder()
    ): Array<String> {
        return if (isVideo) {
            arrayOf(
                "-y",
                "-i", inputPath,
                "-vf", "format=yuv420p,reverse",
                "-af", "areverse",
                "-c:v", videoEncoder,
                "-c:a", "aac",
                "-vsync", "2",
                "-async", "1",
                "-movflags", "+faststart",
                outputPath
            )
        } else {
            val ext = outputPath.substringAfterLast('.', "m4a").lowercase()
            val args = mutableListOf<String>()
            args.add("-y")
            args.add("-i")
            args.add(inputPath)
            args.add("-vn")
            args.add("-map")
            args.add("0:a")
            args.add("-af")
            args.add("areverse")
            if (ext == "mp3" && EncoderDetector.hasMp3Lame) {
                args.add("-c:a")
                args.add("libmp3lame")
            } else {
                args.add("-c:a")
                args.add("aac")
            }
            args.add("-b:a")
            args.add("192k")
            args.add(outputPath)
            args.toTypedArray()
        }
    }

    // Chuyển lệnh có h264_mediacodec sang lệnh sử dụng encoder dự phòng (libx264 hoặc mpeg4)
    fun buildFallbackVideoCommand(originalArgs: Array<String>): Array<String> {
        val fallbackEncoderArgs = EncoderDetector.getFallbackVideoEncoderArgs()
        val result = mutableListOf<String>()
        var i = 0
        while (i < originalArgs.size) {
            val arg = originalArgs[i]
            if (arg == "-c:v") {
                // Bỏ qua "-c:v" và encoder cũ (ví dụ h264_mediacodec)
                i += 2
                // Chèn các tham số encoder dự phòng (-c:v libx264 -preset veryfast -crf 23 hoặc -c:v mpeg4 -q:v 5)
                result.addAll(fallbackEncoderArgs)
            } else if (arg == "-b:v") {
                // Khi dùng CRF hoặc q:v, bỏ -b:v để không xung đột chất lượng mã hoá
                i += 2
            } else {
                result.add(arg)
                i++
            }
        }
        return result.toTypedArray()
    }
}
