package com.example.engine

import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

object EncoderDetector {
    private const val TAG = "EncoderDetector"

    var hasMp3Lame: Boolean = true
        private set

    var hasH264Mediacodec: Boolean = true
        private set

    var hasLibx264: Boolean = true
        private set

    var hasMpeg4: Boolean = true
        private set

    var hasLibVorbis: Boolean = false
        private set

    var hasLibOpus: Boolean = false
        private set

    var hasAmrNb: Boolean = false
        private set

    private val _isDetectionDone = MutableStateFlow(false)
    val isDetectionDone: StateFlow<Boolean> = _isDetectionDone.asStateFlow()

    private val availableEncoders = mutableSetOf<String>()

    fun detectAvailableEncoders() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                Log.d(TAG, "Đang kiểm tra danh sách encoder khả dụng trong FFmpegKit...")
                val session = FFmpegKit.execute("-encoders")
                val logs = session.allLogsAsString ?: ""

                val lines = logs.split("\n")
                for (line in lines) {
                    val trimmed = line.trim()
                    // FFmpeg -encoders format: " V..... h264_mediacodec ... " or " A..... libmp3lame ... "
                    if (trimmed.length > 7 && (trimmed.startsWith("V") || trimmed.startsWith("A") || trimmed.startsWith("S"))) {
                        val parts = trimmed.split(Regex("\\s+"))
                        if (parts.size >= 2) {
                            val encoderName = parts[1].trim()
                            if (encoderName.isNotEmpty()) {
                                availableEncoders.add(encoderName)
                            }
                        }
                    }
                }

                hasMp3Lame = availableEncoders.contains("libmp3lame")
                hasLibx264 = availableEncoders.contains("libx264")
                hasH264Mediacodec = availableEncoders.contains("h264_mediacodec")
                hasMpeg4 = availableEncoders.contains("mpeg4") || true
                hasLibVorbis = availableEncoders.contains("libvorbis")
                hasLibOpus = availableEncoders.contains("libopus")
                hasAmrNb = availableEncoders.contains("libopencore_amrnb")

                Log.i(TAG, "Kiểm tra encoder hoàn tất: " +
                        "libx264=$hasLibx264, " +
                        "mp3lame=$hasMp3Lame, " +
                        "h264_mediacodec=$hasH264Mediacodec, " +
                        "mpeg4=$hasMpeg4, " +
                        "libvorbis=$hasLibVorbis, " +
                        "libopus=$hasLibOpus, " +
                        "amrnb=$hasAmrNb")

                if (hasLibx264) {
                    Log.i(TAG, "Đang dùng libx264 (phần mềm, chất lượng cao) làm bộ mã hóa video chính.")
                } else if (hasH264Mediacodec) {
                    Log.w(TAG, "libx264 không khả dụng, fallback sang: h264_mediacodec (phần cứng).")
                } else {
                    Log.w(TAG, "libx264 và h264_mediacodec không khả dụng, fallback sang: mpeg4.")
                }

                _isDetectionDone.value = true
            } catch (e: Throwable) {
                Log.e(TAG, "Lỗi khi kiểm tra encoder: ${e.message}", e)
                hasLibx264 = true
                hasMp3Lame = true
                hasH264Mediacodec = true
                hasMpeg4 = true
                _isDetectionDone.value = true
            }
        }
    }

    // Thứ tự ưu tiên encoder video mới: 1. libx264 -> 2. h264_mediacodec -> 3. mpeg4
    fun getBestVideoEncoder(): String {
        return if (hasLibx264) {
            "libx264"
        } else if (hasH264Mediacodec) {
            "h264_mediacodec"
        } else {
            "mpeg4"
        }
    }

    // Encoder dự phòng khi libx264 gặp sự cố: thử h264_mediacodec, rồi mpeg4
    fun getFallbackVideoEncoderArgs(): List<String> {
        return if (hasH264Mediacodec) {
            listOf("-c:v", "h264_mediacodec", "-b:v", "4000k")
        } else {
            listOf("-c:v", "mpeg4", "-q:v", "5")
        }
    }

    fun hasEncoder(name: String): Boolean {
        return availableEncoders.contains(name)
    }
}
