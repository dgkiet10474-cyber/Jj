package com.example.engine

import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.Session
import com.example.service.ProcessingService
import com.example.util.FileUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

sealed interface ProcessingState {
    object Idle : ProcessingState

    data class Running(
        val title: String,
        val progressPercent: Float, // 0.0f - 1.0f
        val elapsedSec: Long,
        val processedTimeMs: Long,
        val totalDurationMs: Long
    ) : ProcessingState

    data class Success(
        val outputFile: File,
        val originalSize: Long,
        val outputSize: Long,
        val title: String,
        val isVideo: Boolean
    ) : ProcessingState

    data class Error(
        val errorMessage: String,
        val lastLogs: List<String>
    ) : ProcessingState
}

object ProcessingManager {
    private const val TAG = "ProcessingManager"
    private const val MAX_LOG_LINES = 30

    private val _state = MutableStateFlow<ProcessingState>(ProcessingState.Idle)
    val state: StateFlow<ProcessingState> = _state.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    private var currentSession: Session? = null
    private var isTaskRunning = false
    private var startTimeMs = 0L

    fun isRunning(): Boolean = isTaskRunning

    fun cancelTask() {
        try {
            currentSession?.cancel()
            FFmpegKit.cancel()
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi huỷ tác vụ: ${e.message}", e)
        }
    }

    fun dismissResult() {
        if (!isTaskRunning) {
            _state.value = ProcessingState.Idle
        }
    }

    fun runTask(
        context: Context,
        taskTitle: String,
        inputCacheFile: File,
        outputCacheFile: File,
        isVideo: Boolean,
        targetDisplayName: String,
        argsArray: Array<String>,
        onSuccess: ((File) -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ) {
        if (isTaskRunning) {
            Log.w(TAG, "Một tác vụ khác đang chạy!")
            return
        }

        isTaskRunning = true
        startTimeMs = System.currentTimeMillis()
        val originalSize = inputCacheFile.length()
        _logs.value = emptyList()

        _state.value = ProcessingState.Running(
            title = taskTitle,
            progressPercent = 0.0f,
            elapsedSec = 0L,
            processedTimeMs = 0L,
            totalDurationMs = 0L
        )

        // Start Foreground Service
        startForegroundService(context, taskTitle)

        CoroutineScope(Dispatchers.IO).launch {
            try {
                // 1. Lấy thông tin media để tính duration cho thanh tiến độ
                var totalDurationMs = 0L
                try {
                    val mediaInfoSession = FFprobeKit.getMediaInformation(inputCacheFile.absolutePath)
                    val mediaInfo = mediaInfoSession.mediaInformation
                    if (mediaInfo != null && mediaInfo.duration != null) {
                        val durationSec = mediaInfo.duration.toDoubleOrNull() ?: 0.0
                        totalDurationMs = (durationSec * 1000).toLong()
                        Log.d(TAG, "Thời lượng file gốc: $totalDurationMs ms")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Lỗi lấy thông tin thời lượng: ${e.message}")
                }

                val logBuffer = mutableListOf<String>()

                // 2. Chạy lệnh FFmpeg bất đồng bộ với executeWithArgumentsAsync
                currentSession = FFmpegKit.executeWithArgumentsAsync(
                    argsArray,
                    { session ->
                        // Complete Callback
                        val returnCode = session.returnCode
                        isTaskRunning = false
                        stopForegroundService(context)

                        if (ReturnCode.isSuccess(returnCode)) {
                            Log.i(TAG, "Tác vụ hoàn thành thành công: $taskTitle")

                            // Lưu vào MediaStore (Movies/Music)
                            FileUtils.saveToMediaStore(
                                context,
                                outputCacheFile,
                                isVideo,
                                targetDisplayName
                            )

                            _state.value = ProcessingState.Success(
                                outputFile = outputCacheFile,
                                originalSize = originalSize,
                                outputSize = outputCacheFile.length(),
                                title = taskTitle,
                                isVideo = isVideo
                            )
                            onSuccess?.invoke(outputCacheFile)
                        } else if (ReturnCode.isCancel(returnCode)) {
                            Log.w(TAG, "Tác vụ đã bị người dùng huỷ")
                            _state.value = ProcessingState.Idle
                            try {
                                if (outputCacheFile.exists()) outputCacheFile.delete()
                            } catch (e: Exception) {
                                Log.e(TAG, "Lỗi xoá file huỷ: ${e.message}")
                            }
                        } else {
                            val failureMsg = session.failStackTrace ?: "Mã lỗi: ${returnCode?.value}"
                            Log.e(TAG, "Tác vụ thất bại: $failureMsg")
                            _state.value = ProcessingState.Error(
                                errorMessage = "Xử lý thất bại ($failureMsg).",
                                lastLogs = logBuffer.takeLast(MAX_LOG_LINES)
                            )
                            onError?.invoke(failureMsg)
                        }
                    },
                    { log ->
                        // Log Callback
                        val message = log.message
                        if (message != null) {
                            synchronized(logBuffer) {
                                logBuffer.add(message)
                                if (logBuffer.size > MAX_LOG_LINES * 2) {
                                    logBuffer.removeAt(0)
                                }
                            }
                            _logs.value = logBuffer.takeLast(MAX_LOG_LINES)
                        }
                    },
                    { stats ->
                        // Statistics Callback -> Tính % tiến độ
                        val processedMs = stats.time.toLong()
                        val elapsedSec = (System.currentTimeMillis() - startTimeMs) / 1000

                        var progress = if (totalDurationMs > 0) {
                            (processedMs.toFloat() / totalDurationMs.toFloat()).coerceIn(0f, 0.99f)
                        } else {
                            0.5f // Indeterminate / ước chừng nếu không có duration
                        }

                        _state.value = ProcessingState.Running(
                            title = taskTitle,
                            progressPercent = progress,
                            elapsedSec = elapsedSec,
                            processedTimeMs = processedMs,
                            totalDurationMs = totalDurationMs
                        )

                        // Update Notification
                        ProcessingService.updateProgress(
                            context,
                            taskTitle,
                            (progress * 100).toInt()
                        )
                    }
                )

            } catch (e: Exception) {
                Log.e(TAG, "Lỗi khi khởi chạy FFmpeg: ${e.message}", e)
                isTaskRunning = false
                stopForegroundService(context)
                _state.value = ProcessingState.Error(
                    errorMessage = "Lỗi khởi chạy: ${e.localizedMessage}",
                    lastLogs = listOf(e.stackTraceToString())
                )
            }
        }
    }

    private fun startForegroundService(context: Context, title: String) {
        try {
            val intent = Intent(context, ProcessingService::class.java).apply {
                action = ProcessingService.ACTION_START
                putExtra(ProcessingService.EXTRA_TITLE, title)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi startForegroundService: ${e.message}", e)
        }
    }

    private fun stopForegroundService(context: Context) {
        try {
            val intent = Intent(context, ProcessingService::class.java).apply {
                action = ProcessingService.ACTION_STOP
            }
            context.startService(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi stopForegroundService: ${e.message}", e)
        }
    }
}
