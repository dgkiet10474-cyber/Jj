package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

object FileUtils {
    private const val TAG = "FileUtils"

    fun getFileName(context: Context, uri: Uri): String {
        var name = "media_${System.currentTimeMillis()}"
        if (uri.scheme == "content") {
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1 && cursor.moveToFirst()) {
                        val displayName = cursor.getString(nameIndex)
                        if (!displayName.isNullOrBlank()) {
                            name = displayName
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Lỗi lấy tên file từ content Uri: ${e.message}", e)
            }
        } else {
            uri.path?.let { path ->
                val f = File(path)
                if (f.name.isNotBlank()) {
                    name = f.name
                }
            }
        }
        return name
    }

    fun getFileSize(context: Context, uri: Uri): Long {
        if (uri.scheme == "content") {
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (sizeIndex != -1 && cursor.moveToFirst()) {
                        val size = cursor.getLong(sizeIndex)
                        if (size > 0) return size
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Lỗi lấy dung lượng từ Uri: ${e.message}", e)
            }
        }
        return 0L
    }

    fun copyUriToCache(context: Context, uri: Uri, prefix: String = "input"): File? {
        return try {
            val originalName = getFileName(context, uri)
            val extension = originalName.substringAfterLast('.', "")
            val safeExtension = if (extension.isNotBlank()) ".$extension" else ".tmp"
            val tempFile = File(context.cacheDir, "${prefix}_${System.currentTimeMillis()}$safeExtension")

            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(tempFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            if (tempFile.exists() && tempFile.length() > 0) {
                tempFile
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi copy file vào cache: ${e.message}", e)
            null
        }
    }

    fun createTempOutputFile(context: Context, prefix: String, extension: String): File {
        val extWithDot = if (extension.startsWith(".")) extension else ".$extension"
        return File(context.cacheDir, "${prefix}_${System.currentTimeMillis()}$extWithDot")
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1.0 -> String.format(Locale.US, "%.2f GB", gb)
            mb >= 1.0 -> String.format(Locale.US, "%.2f MB", mb)
            kb >= 1.0 -> String.format(Locale.US, "%.1f KB", kb)
            else -> "$bytes B"
        }
    }

    fun formatDuration(ms: Long): String {
        if (ms < 0) return "00:00"
        val totalSec = ms / 1000
        val hours = totalSec / 3600
        val minutes = (totalSec % 3600) / 60
        val seconds = totalSec % 60
        val millis = ms % 1000

        return if (hours > 0) {
            String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun formatDurationDetailed(ms: Long): String {
        if (ms < 0) return "00:00:00.000"
        val totalSec = ms / 1000
        val hours = totalSec / 3600
        val minutes = (totalSec % 3600) / 60
        val seconds = totalSec % 60
        val millis = ms % 1000

        return String.format(Locale.US, "%02d:%02d:%02d.%03d", hours, minutes, seconds, millis)
    }

    fun parseDurationToMs(timeStr: String): Long? {
        val trimmed = timeStr.trim()
        if (trimmed.isEmpty()) return null

        try {
            // Check if format is pure number of seconds, e.g. "12.5"
            trimmed.toDoubleOrNull()?.let {
                return (it * 1000).toLong()
            }

            val parts = trimmed.split(":")
            return when (parts.size) {
                3 -> {
                    val h = parts[0].toLong()
                    val m = parts[1].toLong()
                    val secParts = parts[2].split(".")
                    val s = secParts[0].toLong()
                    val ms = if (secParts.size > 1) {
                        secParts[1].padEnd(3, '0').take(3).toLong()
                    } else 0L
                    (h * 3600 + m * 60 + s) * 1000 + ms
                }
                2 -> {
                    val m = parts[0].toLong()
                    val secParts = parts[1].split(".")
                    val s = secParts[0].toLong()
                    val ms = if (secParts.size > 1) {
                        secParts[1].padEnd(3, '0').take(3).toLong()
                    } else 0L
                    (m * 60 + s) * 1000 + ms
                }
                1 -> {
                    val secParts = parts[0].split(".")
                    val s = secParts[0].toLong()
                    val ms = if (secParts.size > 1) {
                        secParts[1].padEnd(3, '0').take(3).toLong()
                    } else 0L
                    s * 1000 + ms
                }
                else -> null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi phân tích cú pháp thời gian '$timeStr': ${e.message}")
            return null
        }
    }

    fun saveToMediaStore(
        context: Context,
        sourceFile: File,
        isVideo: Boolean,
        targetFileName: String
    ): Uri? {
        val extension = targetFileName.substringAfterLast('.', "")
        val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.lowercase())
            ?: if (isVideo) "video/mp4" else "audio/mpeg"

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val collection = if (isVideo) {
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else {
                    MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                }

                val relativePath = if (isVideo) {
                    Environment.DIRECTORY_MOVIES + "/MediaForge"
                } else {
                    Environment.DIRECTORY_MUSIC + "/MediaForge"
                }

                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, targetFileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                val itemUri = context.contentResolver.insert(collection, values) ?: return null

                context.contentResolver.openOutputStream(itemUri)?.use { outputStream ->
                    sourceFile.inputStream().use { inputStream ->
                        inputStream.copyTo(outputStream)
                    }
                }

                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                context.contentResolver.update(itemUri, values, null, null)

                itemUri
            } else {
                @Suppress("DEPRECATION")
                val publicDir = Environment.getExternalStoragePublicDirectory(
                    if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_MUSIC
                )
                val targetDir = File(publicDir, "MediaForge")
                if (!targetDir.exists()) targetDir.mkdirs()

                val destFile = File(targetDir, targetFileName)
                sourceFile.copyTo(destFile, overwrite = true)

                // Scan media
                android.media.MediaScannerConnection.scanFile(
                    context,
                    arrayOf(destFile.absolutePath),
                    arrayOf(mimeType),
                    null
                )

                FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    destFile
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi lưu file vào MediaStore: ${e.message}", e)
            null
        }
    }

    fun shareFile(context: Context, file: File) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val extension = file.extension.lowercase()
            val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension) ?: "*/*"

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(shareIntent, "Chia sẻ file qua")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi chia sẻ file: ${e.message}", e)
        }
    }

    fun openFile(context: Context, file: File) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val extension = file.extension.lowercase()
            val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension) ?: "*/*"

            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(viewIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi mở file: ${e.message}", e)
        }
    }

    fun clearCache(context: Context) {
        try {
            val cacheFiles = context.cacheDir.listFiles()
            cacheFiles?.forEach { file ->
                if (file.isFile && (file.name.startsWith("input_") ||
                            file.name.startsWith("output_") ||
                            file.name.startsWith("temp_"))
                ) {
                    file.delete()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi dọn dẹp cache: ${e.message}", e)
        }
    }
}
