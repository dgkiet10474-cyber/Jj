package com.example.util

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

object ExportedFilesManager {
    private val _files = MutableStateFlow<List<ExportedMediaFile>>(emptyList())
    val files: StateFlow<List<ExportedMediaFile>> = _files.asStateFlow()

    private val _fileCount = MutableStateFlow(0)
    val fileCount: StateFlow<Int> = _fileCount.asStateFlow()

    fun refresh(context: Context) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val list = FileUtils.queryExportedMediaFiles(context)
                _files.value = list
                _fileCount.value = list.size
            } catch (e: Throwable) {
                // Giữ an toàn, không để crash
            }
        }
    }
}
