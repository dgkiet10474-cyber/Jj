package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.util.Log
import com.example.engine.EncoderDetector
import com.example.util.FileUtils

class MediaForgeApp : Application() {

    companion object {
        const val CHANNEL_ID = "mediaforge_processing_channel"
        const val CHANNEL_NAME = "MediaForge Tiến trình"
        private const val TAG = "MediaForgeApp"
    }

    override fun onCreate() {
        super.onCreate()

        // Create Notification Channel for Foreground Service
        createNotificationChannel()

        // Clean temp cache files from previous sessions
        try {
            FileUtils.clearCache(this)
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi dọn dẹp cache: ${e.message}", e)
        }

        // Initialize Encoder Detector
        EncoderDetector.detectAvailableEncoders()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Hiển thị tiến trình xử lý media trong nền của MediaForge"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }
    }
}
