package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.EncoderDetector
import com.example.engine.ProcessingManager
import com.example.engine.ProcessingState
import com.example.ui.components.ErrorLogDialog
import com.example.ui.components.ProcessingOverlay
import com.example.ui.components.SuccessResultDialog
import com.example.ui.screens.*
import com.example.ui.theme.MediaForgeTheme
import com.example.util.ExportedFilesManager
import com.example.util.FileUtils

enum class MediaForgeTab(val title: String, val icon: ImageVector) {
    HOME("Trang chủ", Icons.Default.Home),
    OUTPUT("Thư mục đầu ra", Icons.Default.Folder)
}

enum class ActiveScreen {
    MAIN,
    VIDEO_TO_AUDIO,
    AUDIO_TRIM,
    VIDEO_TRIM,
    VIDEO_CONVERT,
    VIDEO_SPEED,
    VIDEO_COMPRESS,
    VIDEO_REVERSE,
    AUDIO_CONVERT,
    AUDIO_SPEED,
    AUDIO_COMPRESS,
    AUDIO_REVERSE
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MediaForgeTheme {
                val context = LocalContext.current

                // Request POST_NOTIFICATIONS on Android 13+ (TIRAMISU)
                val notificationPermissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { /* Notification permission callback */ }

                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        val hasNotificationPerm = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.POST_NOTIFICATIONS
                        ) == PackageManager.PERMISSION_GRANTED
                        if (!hasNotificationPerm) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                    ExportedFilesManager.refresh(context)
                }

                MediaForgeAppContent()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaForgeAppContent() {
    val context = LocalContext.current

    var selectedTab by remember { mutableStateOf(MediaForgeTab.HOME) }
    var activeScreen by remember { mutableStateOf(ActiveScreen.MAIN) }

    // Quản lý trạng thái chọn file trong Tab Thư mục đầu ra
    var isSelectionMode by remember { mutableStateOf(false) }
    val selectedUris = remember { mutableStateListOf<Uri>() }
    var show3DotMenu by remember { mutableStateOf(false) }
    var showBatchDeleteConfirm by remember { mutableStateOf(false) }
    var showInfoDialog by remember { mutableStateOf(false) }

    // Dữ liệu file xuất và số lượng cho badge
    val exportedFiles by ExportedFilesManager.files.collectAsStateWithLifecycle()
    val exportedCount by ExportedFilesManager.fileCount.collectAsStateWithLifecycle()

    // Observe global processing state
    val processingState by ProcessingManager.state.collectAsStateWithLifecycle()

    // Refresh danh sách file khi vào màn hình
    LaunchedEffect(selectedTab) {
        if (selectedTab == MediaForgeTab.OUTPUT) {
            ExportedFilesManager.refresh(context)
        }
    }

    // Xử lý nút Back hệ thống
    // 1. Khi đang ở màn hình chức năng con -> quay về Trang chủ
    BackHandler(enabled = activeScreen != ActiveScreen.MAIN) {
        activeScreen = ActiveScreen.MAIN
    }

    // 2. Khi đang ở Tab Thư mục đầu ra và ĐANG ở chế độ chọn -> thoát chế độ chọn
    BackHandler(enabled = activeScreen == ActiveScreen.MAIN && selectedTab == MediaForgeTab.OUTPUT && isSelectionMode) {
        isSelectionMode = false
        selectedUris.clear()
    }

    // 3. Khi đang ở Tab Thư mục đầu ra (chế độ thường) -> bấm Back chuyển sang Tab Trang chủ
    BackHandler(enabled = activeScreen == ActiveScreen.MAIN && selectedTab == MediaForgeTab.OUTPUT && !isSelectionMode) {
        selectedTab = MediaForgeTab.HOME
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (activeScreen != ActiveScreen.MAIN) {
                        Text(
                            text = when (activeScreen) {
                                ActiveScreen.VIDEO_TO_AUDIO -> "Video đến Âm thanh"
                                ActiveScreen.AUDIO_TRIM -> "Trình cắt Âm thanh"
                                ActiveScreen.VIDEO_TRIM -> "Trình cắt video"
                                ActiveScreen.VIDEO_CONVERT -> "Chuyển đổi Video"
                                ActiveScreen.VIDEO_SPEED -> "Tốc độ Video"
                                ActiveScreen.VIDEO_COMPRESS -> "Bộ nén video"
                                ActiveScreen.VIDEO_REVERSE -> "Đảo ngược video"
                                ActiveScreen.AUDIO_CONVERT -> "Chuyển đổi Âm thanh"
                                ActiveScreen.AUDIO_SPEED -> "Tốc độ Âm thanh"
                                ActiveScreen.AUDIO_COMPRESS -> "Nén âm thanh"
                                ActiveScreen.AUDIO_REVERSE -> "Đảo ngược âm thanh"
                                ActiveScreen.MAIN -> "MediaForge"
                            },
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    } else if (selectedTab == MediaForgeTab.OUTPUT) {
                        Text(
                            text = if (isSelectionMode) "Đã chọn: ${selectedUris.size} file" else "Thư mục đầu ra",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "MediaForge",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                },
                navigationIcon = {
                    if (activeScreen != ActiveScreen.MAIN) {
                        IconButton(onClick = { activeScreen = ActiveScreen.MAIN }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Quay lại"
                            )
                        }
                    } else if (selectedTab == MediaForgeTab.OUTPUT && isSelectionMode) {
                        IconButton(onClick = {
                            isSelectionMode = false
                            selectedUris.clear()
                        }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Thoát chế độ chọn"
                            )
                        }
                    }
                },
                actions = {
                    if (activeScreen == ActiveScreen.MAIN) {
                        if (selectedTab == MediaForgeTab.HOME) {
                            IconButton(onClick = { showInfoDialog = true }) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = "Thông tin hệ thống",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            // Menu 3 chấm đặc biệt ở tab Thư mục đầu ra
                            Box {
                                IconButton(onClick = { show3DotMenu = true }) {
                                    Icon(
                                        imageVector = Icons.Default.MoreVert,
                                        contentDescription = "Tuỳ chọn menu",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                DropdownMenu(
                                    expanded = show3DotMenu,
                                    onDismissRequest = { show3DotMenu = false }
                                ) {
                                    if (!isSelectionMode) {
                                        // Khi CHƯA ở chế độ chọn: chỉ có mục "Chọn file"
                                        DropdownMenuItem(
                                            text = { Text("Chọn file") },
                                            leadingIcon = { Icon(Icons.Default.Checklist, contentDescription = null) },
                                            onClick = {
                                                isSelectionMode = true
                                                show3DotMenu = false
                                            }
                                        )
                                    } else {
                                        // Khi ĐANG ở chế độ chọn:
                                        val isAllSelected = exportedFiles.isNotEmpty() && selectedUris.size == exportedFiles.size
                                        DropdownMenuItem(
                                            text = { Text(if (isAllSelected) "Bỏ chọn tất cả" else "Chọn tất cả") },
                                            leadingIcon = {
                                                Icon(
                                                    if (isAllSelected) Icons.Default.Deselect else Icons.Default.SelectAll,
                                                    contentDescription = null
                                                )
                                            },
                                            onClick = {
                                                if (isAllSelected) {
                                                    selectedUris.clear()
                                                } else {
                                                    selectedUris.clear()
                                                    selectedUris.addAll(exportedFiles.map { it.uri })
                                                }
                                                show3DotMenu = false
                                            }
                                        )

                                        DropdownMenuItem(
                                            text = { Text("Chia sẻ (${selectedUris.size})") },
                                            leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) },
                                            enabled = selectedUris.isNotEmpty(),
                                            onClick = {
                                                val selFiles = exportedFiles.filter { selectedUris.contains(it.uri) }
                                                FileUtils.shareExportedFiles(context, selFiles)
                                                show3DotMenu = false
                                            }
                                        )

                                        DropdownMenuItem(
                                            text = { Text("Xoá (${selectedUris.size})", color = MaterialTheme.colorScheme.error) },
                                            leadingIcon = {
                                                Icon(
                                                    Icons.Default.Delete,
                                                    contentDescription = null,
                                                    tint = if (selectedUris.isNotEmpty()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
                                                )
                                            },
                                            enabled = selectedUris.isNotEmpty(),
                                            onClick = {
                                                showBatchDeleteConfirm = true
                                                show3DotMenu = false
                                            }
                                        )

                                        HorizontalDivider()

                                        DropdownMenuItem(
                                            text = { Text("Thoát chế độ chọn") },
                                            leadingIcon = { Icon(Icons.Default.Close, contentDescription = null) },
                                            onClick = {
                                                isSelectionMode = false
                                                selectedUris.clear()
                                                show3DotMenu = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            // Chỉ hiển thị Bottom Navigation khi ở màn hình chính (2 tab)
            if (activeScreen == ActiveScreen.MAIN) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    MediaForgeTab.entries.forEach { tab ->
                        val isSelected = selectedTab == tab
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                if (selectedTab != tab) {
                                    isSelectionMode = false
                                    selectedUris.clear()
                                    selectedTab = tab
                                }
                            },
                            icon = {
                                if (tab == MediaForgeTab.OUTPUT) {
                                    BadgedBox(
                                        badge = {
                                            if (exportedCount > 0) {
                                                Badge(
                                                    containerColor = MaterialTheme.colorScheme.primary,
                                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                                ) {
                                                    Text(exportedCount.toString())
                                                }
                                            }
                                        }
                                    ) {
                                        Icon(tab.icon, contentDescription = tab.title)
                                    }
                                } else {
                                    Icon(tab.icon, contentDescription = tab.title)
                                }
                            },
                            label = { Text(tab.title, style = MaterialTheme.typography.labelSmall) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (activeScreen == ActiveScreen.MAIN) {
                when (selectedTab) {
                    MediaForgeTab.HOME -> {
                        HomeScreen(
                            onActionClick = { action ->
                                activeScreen = when (action) {
                                    HomeAction.VIDEO_TO_AUDIO -> ActiveScreen.VIDEO_TO_AUDIO
                                    HomeAction.AUDIO_TRIM -> ActiveScreen.AUDIO_TRIM
                                    HomeAction.VIDEO_TRIM -> ActiveScreen.VIDEO_TRIM
                                    HomeAction.VIDEO_CONVERT -> ActiveScreen.VIDEO_CONVERT
                                    HomeAction.VIDEO_SPEED -> ActiveScreen.VIDEO_SPEED
                                    HomeAction.VIDEO_COMPRESS -> ActiveScreen.VIDEO_COMPRESS
                                    HomeAction.VIDEO_REVERSE -> ActiveScreen.VIDEO_REVERSE
                                    HomeAction.AUDIO_CONVERT -> ActiveScreen.AUDIO_CONVERT
                                    HomeAction.AUDIO_SPEED -> ActiveScreen.AUDIO_SPEED
                                    HomeAction.AUDIO_COMPRESS -> ActiveScreen.AUDIO_COMPRESS
                                    HomeAction.AUDIO_REVERSE -> ActiveScreen.AUDIO_REVERSE
                                }
                            }
                        )
                    }
                    MediaForgeTab.OUTPUT -> {
                        OutputFilesScreen(
                            files = exportedFiles,
                            isSelectionMode = isSelectionMode,
                            selectedUris = selectedUris.toSet(),
                            onToggleSelect = { fileItem ->
                                if (selectedUris.contains(fileItem.uri)) {
                                    selectedUris.remove(fileItem.uri)
                                } else {
                                    selectedUris.add(fileItem.uri)
                                }
                            },
                            onRefresh = {
                                ExportedFilesManager.refresh(context)
                            }
                        )
                    }
                }
            } else {
                // Hiển thị màn hình chức năng tương ứng với nút Back trên TopBar
                when (activeScreen) {
                    ActiveScreen.VIDEO_TO_AUDIO -> ConvertScreen(initialMode = 0, filterVideoInputOnly = true)
                    ActiveScreen.AUDIO_TRIM -> TrimScreen(mediaType = "audio")
                    ActiveScreen.VIDEO_TRIM -> TrimScreen(mediaType = "video")
                    ActiveScreen.VIDEO_CONVERT -> ConvertScreen(initialMode = 1)
                    ActiveScreen.VIDEO_SPEED -> SpeedScreen(targetMediaType = "video")
                    ActiveScreen.VIDEO_COMPRESS -> CompressScreen(targetMediaType = "video")
                    ActiveScreen.VIDEO_REVERSE -> ReverseScreen(targetMediaType = "video")
                    ActiveScreen.AUDIO_CONVERT -> ConvertScreen(initialMode = 0)
                    ActiveScreen.AUDIO_SPEED -> SpeedScreen(targetMediaType = "audio")
                    ActiveScreen.AUDIO_COMPRESS -> CompressScreen(targetMediaType = "audio")
                    ActiveScreen.AUDIO_REVERSE -> ReverseScreen(targetMediaType = "audio")
                    ActiveScreen.MAIN -> { /* Không rơi vào đây */ }
                }
            }

            // Hộp thoại xác nhận xoá nhiều file được chọn
            if (showBatchDeleteConfirm) {
                AlertDialog(
                    onDismissRequest = { showBatchDeleteConfirm = false },
                    icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                    title = { Text("Xác nhận xoá ${selectedUris.size} file") },
                    text = {
                        Text("Bạn có chắc chắn muốn xoá vĩnh viễn ${selectedUris.size} file đã chọn khỏi thiết bị không? Hành động này không thể hoàn tác.")
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                val filesToDelete = exportedFiles.filter { selectedUris.contains(it.uri) }
                                val count = filesToDelete.size
                                FileUtils.deleteMultipleExportedMediaFiles(context, filesToDelete)
                                selectedUris.clear()
                                isSelectionMode = false
                                showBatchDeleteConfirm = false
                                ExportedFilesManager.refresh(context)
                                Toast.makeText(context, "Đã xoá $count file thành công", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Xoá tất cả")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showBatchDeleteConfirm = false }) {
                            Text("Huỷ")
                        }
                    }
                )
            }

            // Global Overlays & Dialogs based on ProcessingState
            when (val current = processingState) {
                is ProcessingState.Running -> {
                    ProcessingOverlay(
                        state = current,
                        onCancel = { ProcessingManager.cancelTask() }
                    )
                }
                is ProcessingState.Error -> {
                    ErrorLogDialog(
                        state = current,
                        onDismiss = { ProcessingManager.dismissResult() }
                    )
                }
                is ProcessingState.Success -> {
                    SuccessResultDialog(
                        state = current,
                        onDismiss = { ProcessingManager.dismissResult() }
                    )
                }
                is ProcessingState.Idle -> { /* Idle */ }
            }

            // System Info Dialog
            if (showInfoDialog) {
                AlertDialog(
                    onDismissRequest = { showInfoDialog = false },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    title = { Text("Thông tin MediaForge") },
                    text = {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "Bộ công cụ xử lý video và âm thanh offline",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "• Hoạt động 100% offline trên thiết bị, bảo mật tuyệt đối.\n" +
                                        "• Engine: FFmpegKit maintained 7.1.6 (Full-GPL).\n" +
                                        "• Bộ mã hóa video: ${EncoderDetector.getBestVideoEncoder()} (ưu tiên libx264 chất lượng cao)\n" +
                                        "• Hỗ trợ MP3 Lame: Có (libmp3lame trực tiếp)\n" +
                                        "• Tiến trình nền: Chạy qua Foreground Service không lo bị kill.\n" +
                                        "• Xoá metadata: Tự động loại bỏ ID3 và thẻ tag khi chuyển đổi âm thanh.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showInfoDialog = false }) {
                            Text("Đóng")
                        }
                    }
                )
            }
        }
    }
}
