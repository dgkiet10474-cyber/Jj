package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.EncoderDetector
import com.example.engine.ProcessingManager
import com.example.engine.ProcessingState
import com.example.ui.components.ErrorLogDialog
import com.example.ui.components.ProcessingOverlay
import com.example.ui.components.SuccessResultDialog
import com.example.ui.screens.*
import com.example.ui.theme.MediaForgeTheme

enum class MediaForgeTab(val title: String, val icon: ImageVector) {
    CONVERT("Chuyển đổi", Icons.Default.Transform),
    TRIM("Cắt", Icons.Default.ContentCut),
    COMPRESS("Nén", Icons.Default.Compress),
    SPEED("Tốc độ", Icons.Default.Speed),
    REVERSE("Đảo ngược", Icons.Default.FastRewind)
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MediaForgeTheme {
                val context = LocalContext.current

                // Request POST_NOTIFICATIONS on Android 13+ (TIRAMISU)
                val notificationPermissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { /* Handle notification permission result */ }

                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        val hasNotificationPerm = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.POST_NOTIFICATIONS
                        ) == PackageManager.PERMISSION_GRANTED
                        if (!hasNotificationPerm) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                }

                MediaForgeMainScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaForgeMainScreen() {
    var selectedTab by remember { mutableStateOf(MediaForgeTab.CONVERT) }
    var showInfoDialog by remember { mutableStateOf(false) }

    // Observe global processing state
    val processingState by ProcessingManager.state.collectAsStateWithLifecycle()

    BackHandler(enabled = selectedTab != MediaForgeTab.CONVERT) {
        selectedTab = MediaForgeTab.CONVERT
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "MediaForge",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showInfoDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Thông tin hệ thống",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                MediaForgeTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Icon(tab.icon, contentDescription = tab.title) },
                        label = { Text(tab.title, style = MaterialTheme.typography.labelSmall) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                MediaForgeTab.CONVERT -> ConvertScreen()
                MediaForgeTab.TRIM -> TrimScreen()
                MediaForgeTab.COMPRESS -> CompressScreen()
                MediaForgeTab.SPEED -> SpeedScreen()
                MediaForgeTab.REVERSE -> ReverseScreen()
            }

            // Global Overlays & Dialogs based on ProcessingState
            when (val current = processingState) {
                is ProcessingState.Running -> {
                    ProcessingOverlay(
                        state = current,
                        onCancel = { ProcessingManager.cancelTask() }
                    )
                }
                is ProcessingState.Error -> {
                    ErrorLogDialog(
                        state = current,
                        onDismiss = { ProcessingManager.dismissResult() }
                    )
                }
                is ProcessingState.Success -> {
                    SuccessResultDialog(
                        state = current,
                        onDismiss = { ProcessingManager.dismissResult() }
                    )
                }
                is ProcessingState.Idle -> { /* Idle */ }
            }

            // System Info Dialog
            if (showInfoDialog) {
                AlertDialog(
                    onDismissRequest = { showInfoDialog = false },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    title = { Text("Thông tin MediaForge") },
                    text = {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "Bộ công cụ xử lý video và âm thanh offline",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "• Hoạt động 100% offline trên thiết bị, bảo mật tuyệt đối.\n" +
                                        "• Engine: FFmpegKit maintained 7.1.6.\n" +
                                        "• Bộ mã hóa video: ${EncoderDetector.getBestVideoEncoder()}\n" +
                                        "• Hỗ trợ MP3 Lame: ${if (EncoderDetector.hasMp3Lame) "Có" else "Không (sử dụng AAC fallback)"}\n" +
                                        "• Tiến trình nền: Chạy qua Foreground Service không lo bị kill.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showInfoDialog = false }) {
                            Text("Đóng")
                        }
                    }
                )
            }
        }
    }
}
