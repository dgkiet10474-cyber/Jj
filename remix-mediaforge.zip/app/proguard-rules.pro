# ProGuard / R8 Rules for MediaForge

# FFmpegKit & SmartException
-keep class com.arthenica.** { *; }
-dontwarn com.arthenica.**

# Media3 ExoPlayer
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Keep models and reflection
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
