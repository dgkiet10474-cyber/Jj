# ProGuard / R8 Rules for MediaForge

# FFmpegKit
-keep class com.arthenica.ffmpegkit.** { *; }
-dontwarn com.arthenica.ffmpegkit.**

# Media3 ExoPlayer
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Keep models and reflection
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
