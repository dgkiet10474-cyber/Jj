# ProGuard / R8 Rules for MediaForge

# ==============================================================================
# 1. Thuộc tính Reflection & Annotation Metadata
# ==============================================================================
-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*
-keepattributes SourceFile,LineNumberTable

# ==============================================================================
# 2. JNI & C/C++ Native Methods
# Rất quan trọng với FFmpeg: giữ nguyên tên và signature của mọi phương thức native
# ==============================================================================
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}

# ==============================================================================
# 3. FFmpegKit & SmartException
# ==============================================================================
-keep class com.arthenica.** { *; }
-dontwarn com.arthenica.**
-keep class com.arthenica.smartexception.** { *; }
-keep class dev.ffmpegkit.** { *; }
-dontwarn dev.ffmpegkit.**

# ==============================================================================
# 4. Kotlin Coroutines
# ==============================================================================
-keepclassmembernames class kotlinx.** {
    volatile <fields>;
}
-dontwarn kotlinx.coroutines.**

# ==============================================================================
# 5. Jetpack Compose
# AGP và Compose Compiler đã nhúng sẵn một phần ProGuard rules,
# nhưng bổ sung các rule an toàn sau để tránh cảnh báo hoặc stripping ngoài ý muốn:
# ==============================================================================
-dontwarn androidx.compose.**
-keep class androidx.compose.runtime.** { *; }
-keep class * extends androidx.compose.runtime.State { *; }

# ==============================================================================
# 6. Android Architecture & ViewModel
# ==============================================================================
-keepclassmembers class * extends androidx.lifecycle.ViewModel {
    <init>(...);
}

# ==============================================================================
# 7. Media3 / ExoPlayer
# Giữ các class decode, renderer và models dùng reflection trong ExoPlayer
# ==============================================================================
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**
-keepclassmembers class androidx.media3.common.Format { *; }
-keepclassmembers class androidx.media3.exoplayer.** { *; }

# ==============================================================================
# 8. ProfileInstaller & Baseline Profile
# ==============================================================================
-dontwarn androidx.profileinstaller.**
-keep class androidx.profileinstaller.** { *; }
